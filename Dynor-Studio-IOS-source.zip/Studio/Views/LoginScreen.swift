import SwiftUI

struct LoginScreen: View {
    @Environment(StudioModel.self) private var model
    @State private var email = ""
    @State private var sentEmail: String?
    @State private var otp = ""
    @State private var password = ""
    @State private var passwordMode = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    VStack(alignment: .leading, spacing: 12) {
                        Image(systemName: "lock.shield.fill")
                            .font(.system(size: 44, weight: .medium)).foregroundStyle(.tint)
                        Text("Dynor Studio").font(.largeTitle.bold())
                        Text(L10n.text("adminLogin")).foregroundStyle(.secondary)
                    }.padding(.top, 32)
                    StudioCard {
                        VStack(alignment: .leading, spacing: 16) {
                            TextField(L10n.text("email"), text: $email)
                                .textContentType(.emailAddress).keyboardType(.emailAddress)
                                .autocorrectionDisabled().textInputAutocapitalization(.never)
                                .padding(12).background(StudioDesign.canvas, in: .rect(cornerRadius: 12))
                            if passwordMode {
                                SecureField(L10n.text("password"), text: $password).textContentType(.password)
                                    .padding(12).background(StudioDesign.canvas, in: .rect(cornerRadius: 12))
                                StudioAction(key: "signIn", symbol: "arrow.right", primary: true) {
                                    Task {
                                        await model.login { try await model.auth.password(email: email.trimmed, password: password) }
                                        password = ""
                                    }
                                }.disabled(password.isEmpty)
                            } else {
                                if sentEmail == email.trimmed {
                                    TextField(L10n.text("otp"), text: $otp)
                                        .textContentType(.oneTimeCode).keyboardType(.numberPad)
                                        .padding(12).background(StudioDesign.canvas, in: .rect(cornerRadius: 12))
                                    StudioAction(key: "signIn", symbol: "arrow.right", primary: true) {
                                        Task { await model.login { try await model.auth.verify(email: email.trimmed, otp: otp.trimmed) } }
                                    }.disabled(otp.trimmed.isEmpty)
                                }
                                StudioAction(key: sentEmail == email.trimmed ? "resendOTP" : "sendOTP",
                                             symbol: "envelope", primary: sentEmail != email.trimmed) {
                                    Task {
                                        await model.work.run {
                                            let recipient = email.trimmed
                                            try await model.auth.sendOTP(email: recipient)
                                            sentEmail = recipient
                                            model.work.notice = L10n.text("otpSent")
                                        }
                                    }
                                }.disabled(email.trimmed.isEmpty)
                            }
                            Button(L10n.text(passwordMode ? "useOTP" : "usePassword")) {
                                passwordMode.toggle()
                                password = ""
                                model.work.error = nil
                                model.work.notice = nil
                            }
                        }.disabled(model.work.busy)
                    }
                    WorkStatus(work: model.work)
                    if !model.initialCheckDone {
                        Button(L10n.text("restoreSession")) { Task { await model.restore() } }
                            .disabled(model.work.busy)
                    }
                }.frame(maxWidth: 480).padding(24).frame(maxWidth: .infinity)
            }
            .background(StudioDesign.canvas)
        }
    }
}

struct LockScreen: View {
    @Environment(StudioModel.self) private var model

    var body: some View {
        VStack(spacing: 18) {
            Image(systemName: "faceid").font(.system(size: 48)).foregroundStyle(.tint)
            Text("Dynor Studio").font(.largeTitle.bold())
            StudioAction(key: "unlock", symbol: "faceid", primary: true) {
                Task { await model.work.run { try await model.authenticateFace() } }
            }.disabled(model.work.busy)
            WorkStatus(work: model.work)
            Button(L10n.text("signOut"), role: .destructive) { Task { await model.logout() } }
                .disabled(model.work.busy)
        }.padding(24).frame(maxWidth: 420)
    }
}
