import CryptoKit
import Foundation
import XCTest
@testable import DynorStudio

final class PackageInteropTests: XCTestCase {
    private struct Vector: Decodable {
        let package_id: UUID
        let key_base64: Data
        let nonce_base64: Data
        let plaintext_base64: Data
        let encrypted_base64: Data
        let sha256: String
    }

    func testMatchesOriginalVaultByteForByte() throws {
        let fixture = try XCTUnwrap(Bundle(for: Self.self).url(forResource: "interop-v1", withExtension: "json"))
        let vector = try JSONDecoder().decode(Vector.self, from: Data(contentsOf: fixture))
        let key = SymmetricKey(data: vector.key_base64)
        let nonce = try AES.GCM.Nonce(data: vector.nonce_base64)
        let produced = try VaultService.seal(vector.plaintext_base64, id: vector.package_id, key: key, nonce: nonce)
        XCTAssertEqual(produced, vector.encrypted_base64)
        let info = try PackageInfo(produced)
        XCTAssertEqual(info.id, vector.package_id.uuidString.lowercased())
        XCTAssertEqual(info.sha, vector.sha256)
        let box = try AES.GCM.SealedBox(combined: Data(produced.dropFirst(24)))
        XCTAssertEqual(try AES.GCM.open(box, using: key, authenticating: produced.prefix(24)),
                       vector.plaintext_base64)
    }

    func testRejectsUnencryptedAndTruncatedFiles() throws {
        XCTAssertThrowsError(try PackageInfo(Data("DYNORT01".utf8)))
        XCTAssertThrowsError(try PackageInfo(Data(repeating: 0, count: 300)))
        XCTAssertThrowsError(try VaultService.seal(Data("invalid".utf8), id: UUID(),
                                                  key: SymmetricKey(size: .bits256), nonce: AES.GCM.Nonce()))
    }

    func testExpiryFilterEscapesOffset() {
        let url = APIClient.url("rest/v1/dynor_app_control", query: [
            .init(name: "updated_at", value: "eq.2026-11-24T10:01:00+00:00")
        ])
        XCTAssertTrue(url.absoluteString.contains("%2B00:00") || url.absoluteString.contains("%2B00%3A00"))
    }

    func testAccessPayloads() throws {
        let credits = AccountChange.credits(-5).payload
        XCTAssertEqual(credits.0, "credits")
        let bytes = try JSONEncoder().encode(credits.1)
        XCTAssertEqual(try JSONSerialization.jsonObject(with: bytes) as? [String: Int], ["delta": -5])
        let gift = AccountChange.gift(wallpaper: "wall-id", days: 0).payload
        XCTAssertEqual(gift.0, "gift")
        let object = try JSONSerialization.jsonObject(with: JSONEncoder().encode(gift.1)) as? [String: Any]
        XCTAssertEqual(object?["wallpaper_id"] as? String, "wall-id")
        XCTAssertEqual(object?["days"] as? Int, 0)
    }
}
