import SwiftUI

struct OverviewScreen: View {
    @Environment(StudioModel.self) private var model
    @State private var wallpaperWork = Work()
    @State private var controlWork = Work()
    @State private var auditWork = Work()
    @State private var walls: [Wallpaper]?
    @State private var system: ControlConfig?
    @State private var audit: [AuditEntry]?
    @ScaledMetric(relativeTo: .body) private var tileWidth = 140

    private var vipCount: Int? {
        guard let accounts = model.accounts, accounts.allSatisfy({ $0.quota?.active != nil }) else { return nil }
        return accounts.filter { $0.quota?.active == true }.count
    }

    var body: some View {
        List {
            Section {
                HStack(spacing: 14) {
                    Image(systemName: "lock.shield.fill").font(.title).foregroundStyle(.tint)
                    VStack(alignment: .leading, spacing: 5) {
                        Text("Dynor Studio").font(.title2.bold())
                        Label(L10n.text(model.online.map { $0 ? "connected" : "unreachable" } ?? "checking"),
                              systemImage: model.online == true ? "checkmark.circle" : "network")
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                }.padding(.vertical, 8)
                if let system {
                    LabeledContent(L10n.text("maintenance"), value: L10n.text(system.maintenance_enabled ? "active" : "inactive"))
                    LabeledContent(L10n.text("currentDynor"), value: system.latest_version?.nonEmpty ?? "—")
                }
                WorkStatus(work: controlWork) { Task { await loadControl() } }
            }
            Section(L10n.text("accountMetrics")) {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: tileWidth))], alignment: .leading, spacing: 10) {
                    metric("totalAccounts", value: model.accounts?.count, symbol: "person.2")
                    metric("vipMembers", value: vipCount, symbol: "person.crop.circle.badge.checkmark")
                }
                .listRowInsets(EdgeInsets())
                .listRowBackground(Color.clear)
                if model.accountsWork.busy || model.accountsWork.error != nil {
                    WorkStatus(work: model.accountsWork) { Task { await model.refreshAccounts() } }
                }
                if model.accounts != nil, vipCount == nil {
                    Text(L10n.text("vipCountUnavailable")).font(.footnote).foregroundStyle(.secondary)
                }
            }
            Section(L10n.text("wallpapers")) {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: tileWidth))], alignment: .leading, spacing: 10) {
                    metric("totalWallpapers", value: walls?.count, symbol: "photo.on.rectangle")
                    ForEach(Tier.allCases) { tier in
                        metric(tier.rawValue, value: walls.map { $0.filter { $0.tier == tier }.count }, symbol: tier.symbol)
                    }
                }
                .listRowInsets(EdgeInsets())
                .listRowBackground(Color.clear)
                if wallpaperWork.busy || wallpaperWork.error != nil {
                    WorkStatus(work: wallpaperWork) { Task { await loadWallpapers() } }
                }
                if let walls, walls.contains(where: { $0.tier == nil }) {
                    Label(L10n.text("unknownTierExists"), systemImage: "exclamationmark.circle")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            Section(L10n.text("quickActions")) {
                Button(L10n.text("publish"), systemImage: "plus.app") { model.publish() }
                Button(L10n.text("encrypt"), systemImage: "lock") { model.tab = .vault }
                Button(L10n.text("grantVIP"), systemImage: "person.badge.plus") { model.users(.vip) }
                Button(L10n.text("grantWallpaper"), systemImage: "gift") { model.users(.gift) }
                NavigationLink { ControlScreen() } label: { Label(L10n.text("control"), systemImage: "switch.2") }
            }
            Section(L10n.text("recentActivity")) {
                WorkStatus(work: auditWork) { Task { await loadAudit() } }
                if audit?.isEmpty == true { Text(L10n.text("noAudit")).foregroundStyle(.secondary) }
                ForEach(Array((audit ?? []).prefix(5).enumerated()), id: \.offset) { _, entry in AuditRow(entry: entry) }
                NavigationLink { AuditScreen() } label: { Label(L10n.text("audit"), systemImage: "clock.arrow.circlepath") }
            }
        }
        .navigationTitle(L10n.text("overview"))
        .task { await reload(forceAccounts: false) }
        .refreshable { await reload(forceAccounts: true) }
        .onChange(of: model.wallpaperRevision) { _, _ in Task { await loadWallpapers() } }
        .onChange(of: model.accessRevision) { _, _ in Task { await loadAudit() } }
        .onChange(of: model.controlRevision) { _, _ in Task { await loadControl() } }
    }

    private func metric(_ key: String, value: Int?, symbol: String?) -> some View {
        StudioCard {
            VStack(alignment: .leading, spacing: 7) {
                if let symbol { Image(systemName: symbol).foregroundStyle(.tint).accessibilityHidden(true) }
                Text(value?.formatted() ?? "—").font(.title2.weight(.semibold).monospacedDigit())
                    .contentTransition(.numericText())
                Text(L10n.text(key)).font(.footnote).foregroundStyle(.secondary)
            }.frame(maxWidth: .infinity, minHeight: 78, alignment: .leading)
        }.accessibilityElement(children: .combine)
    }

    private func reload(forceAccounts: Bool) async {
        async let a: Void = model.refreshAccounts(force: forceAccounts)
        async let w: Void = loadWallpapers()
        async let c: Void = loadControl()
        async let log: Void = loadAudit()
        _ = await (a, w, c, log)
    }

    private func loadWallpapers() async {
        await wallpaperWork.run { walls = try await model.wallpapers.list() }
    }

    private func loadControl() async {
        await controlWork.run {
            await model.recheck()
            system = try await model.control.load()
        }
    }

    private func loadAudit() async {
        await auditWork.run { audit = try await model.access.audit() }
    }
}
