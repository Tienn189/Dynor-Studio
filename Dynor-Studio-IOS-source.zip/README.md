# Dynor Studio

Ứng dụng quản trị SwiftUI cho Dynor. Bundle ID **com.dynor.studio**, phiên bản **1.0.0 Beta 1**, build **2**. Deployment target iOS 26.0. Thanh tab dùng Liquid Glass của hệ thống. Info.plist cho phép iPhone ProMotion sử dụng nhịp làm tươi cao theo điều kiện của iOS.

## Build IPA unsigned

### Codemagic

1. Đặt **Dynor-Studio-IOS-source.zip** và **codemagic.yaml** ở thư mục gốc của cùng một repository Git. Có thể dùng repo riêng. Nếu nhánh build khác main, sửa branch_patterns trong YAML.
2. Thêm repository vào Codemagic, chọn **codemagic.yaml**, sau đó chạy workflow **Dynor Studio | Unsigned IPA**. Sau khi kết nối webhook, push lên nhánh đã cấu hình sẽ kích hoạt workflow.
3. Workflow giải nén ZIP, dùng Xcode trên máy macOS và cài XcodeGen nếu cần. Script yêu cầu SDK iOS 26 trở lên và build Release cho thiết bị với ký mã tắt.
4. Tải **Dynor-Studio-unsigned-download.zip** trong **Artifacts**. Trên iPhone, mở **Tệp** và chạm ZIP để lấy **Dynor-Studio-unsigned.ipa**. Nếu Codemagic gom tệp vào một ZIP Artifacts chung, giải nén ZIP đó trước.

### Build tại máy Mac

    unzip Dynor-Studio-IOS-source.zip -d DynorStudio
    cd DynorStudio
    brew install xcodegen
    bash scripts/build-unsigned.sh

Tệp IPA xuất hiện ở build/ipa/Dynor-Studio-unsigned.ipa. Tham số đầu của script có thể chỉ định thư mục đầu ra khác. Để chạy XCTest, dùng **xcodegen generate**, mở DynorStudio.xcodeproj, chọn scheme DynorStudio và thiết bị mô phỏng iOS 26, rồi chạy **Product → Test**.

## Chức năng đã triển khai

| Phân hệ | Chức năng |
| --- | --- |
| Đăng nhập | OTP cho tài khoản hiện có và mật khẩu nếu Supabase Auth chấp nhận. Kiểm tra dynor_admins khi đăng nhập, trở lại ứng dụng và trước các yêu cầu có quyền quản trị. Một phiên Keychain dùng chung, làm mới token, khóa Face ID, đăng xuất và thoát phiên khi mất quyền. |
| Tổng quan | Đếm tài khoản và VIP từ các trang list của Dynor Access. Đếm hình nền và phân loại từ dynor_wallpapers. Trạng thái kết nối, bảo trì, phiên bản cấu hình từ Control, hoạt động gần đây từ Access và năm thao tác nhanh. |
| Vault | Nhập Tendies từ Tệp, mã hóa AES-256-GCM ở nền, tiến trình theo giai đoạn, xác nhận đăng ký UUID và SHA-256 trước khi xuất, chia sẻ hoặc chuyển gói sang trình đăng. |
| Hình nền | Danh sách, tìm kiếm, lọc phân loại và trạng thái, đăng/sửa/xóa, ảnh bìa, AVPlayer, tải ảnh/video/gói với tiến trình, công khai/ẩn, kiểm tra gói và đồng bộ mỗi bản ghi hoặc cả danh sách. |
| Người dùng | Phân trang theo hợp đồng gốc, tìm email toàn bộ các trang, UID, ngày đăng ký, lần đăng nhập cuối, VIP, thời hạn, lượt Crown, cấp/sửa/thu hồi VIP, điều chỉnh lượt, cấp/thu hồi quyền hình nền có thời hạn hoặc vĩnh viễn và nhật ký Access. |
| Control | Đọc/ghi hàng id=1, toàn bộ trường cập nhật và bảo trì, tải lại dữ liệu và hộp thoại xác nhận khi ghi. Kiểm tra updated_at giảm ghi đè khi nhiều Admin cùng thao tác. |
| Cài đặt | Tiếng Việt, tiếng Anh, tiếng Trung giản thể, màu vàng nhẹ và màu tùy chỉnh, sáng/tối/hệ thống, Face ID, phiên bản và thiết bị, kiểm tra kết nối, Control, nhật ký và đăng xuất. |

Tổng quan và Người dùng đọc chung danh sách tài khoản trong phiên Studio. Ứng dụng tải các trang Dynor Access đến trang trống và kiểm tra UID trùng. Cả hai màn hình đếm từ cùng danh sách UID. Người dùng phân trang trên thiết bị, hiển thị riêng số hồ sơ trên trang và số kết quả tìm kiếm. Kéo xuống trên một trong hai màn hình để tải lại. Hoạt động gần đây hiển thị những sự kiện Edge Function dynor-access trả về.

Một số bản ghi cũ chỉ có URL Tendies công khai. Để chuyển chúng sang luồng mã hóa, chọn một gói .dynor đã đăng ký và lưu lại. Với gói ở sát giới hạn 50 MiB, Storage cần chấp nhận phần overhead 52 byte của Vault. Kiểm tra giới hạn thực tế của bucket nếu Supabase báo tệp quá lớn.

## Nguồn đối chiếu và backend

- HTML 4 là Vault. Dùng DYNORT01 theo bố cục 8 byte magic, 16 byte UUID, 12 byte nonce, ciphertext và 16 byte tag. AAD là 24 byte đầu. Gửi package_id, sha256, key_base64, original_name, requires_vip và access_tier tới dynor-register-package. requires_vip được bật với Premium/Crown.
- HTML 3 là Admin. Gửi đúng bốn tham số p_id, p_record, p_package_id, p_sha256 tới RPC dynor_admin_save_wallpaper. Giữ hai bucket dynor-wallpapers và dynor-downloads. Các gói được đọc qua Storage với token Admin. Ảnh/video của Studio dùng URL ký ngắn hạn nếu Storage cho phép và URL công khai hiện hữu làm đường dự phòng. Bản ghi vẫn dùng is_vip cho Crown và cả hai cờ published, is_published.
- HTML 6 là Access. Giữ nguyên action và payload list, wallpapers, gifts, audit, vip, revoke_vip, credits, gift, revoke_gift. Các giá trị gói gửi lên là week, month, quarter, lifetime.
- HTML 5 là Control. Sửa trực tiếp dynor_app_control với ID 1 như website.
- ZIP iOS cung cấp hệ màu grouped, kiểu chữ hệ thống, góc 20 pt, Liquid Glass có Reduce Transparency, bộ giải mã và fixture tương thích. Dynor Studio dùng biểu tượng riêng. [Dynor iOS](https://github.com/Tienn189/Dynor/blob/main/Dynor-IOS-source.zip)

Studio sử dụng Project URL và publishable key công khai có trong các website gốc. Quyền thực thi phải do RLS, RPC và Edge Function xác thực. Chưa áp dụng thay đổi nào lên Supabase.

- **backend/inspect.sql** đọc tên RPC, các bucket và policy hiện có.
- **backend/optional-control-admin-update.sql** bổ sung quyền ghi hàng 1 cho Admin nếu Supabase còn dùng SQL Control trong ZIP iOS, vốn chỉ có quyền đọc.
- **backend/optional-storage-admin.sql** cung cấp quyền Storage giới hạn vào Admin và hai bucket hiện hữu nếu còn thiếu các policy tương đương. Giữ nguyên cấu hình public/private của từng bucket. Kiểm tra cả các policy khác đang có trên dự án vì policy permissive có thể kết hợp bằng OR.
- Các SQL tùy chọn dựa trên public.dynor_is_admin() từ ZIP. Chỉ xem xét áp dụng ở môi trường kiểm thử trước, sau khi xác nhận chính sách tương đương hiện chưa được triển khai. Cần bản đã triển khai của RPC Admin và Edge Function Access nếu dự án đích thiếu chúng. Hai HTML lưu hợp đồng gọi nhưng ZIP không có mã nguồn đầy đủ của RPC và Access.

Email template của Supabase phải gửi mã **{{ .Token }}** cho luồng nhập OTP. Tài khoản thử nghiệm cần có bản ghi trong dynor_admins. Nếu bucket ảnh/video đang private, xác minh riêng khả năng hiển thị trong ứng dụng khách Dynor với cơ chế cấp URL hiện tại của hệ thống.

## Kiểm thử trên môi trường đích còn lại

- Build XcodeGen/Xcode hoàn chỉnh, chạy workflow Codemagic, cài IPA sau ký, thiết bị iOS 26.6, ProMotion và kiểm tra giao diện ba ngôn ngữ trên iPhone/iPad.
- OTP/mật khẩu, refresh token, Keychain, thu hồi Admin, RLS đối với tài khoản thường và Face ID trên iPhone thực.
- Mã hóa, đăng ký, chia sẻ, xuất và cài thử gói do Studio tạo bằng Dynor. Thử gói gần 50 MiB với giới hạn hiện tại của Storage.
- CRUD hình nền, ảnh/video, gói private, quyền Admin Storage, xác minh/hash/liên kết RPC, dọn tệp cũ và các trường hợp mạng ngắt sau khi gửi lệnh lưu.
- Danh sách và số liệu thật, VIP, lượt Crown, quà có thời hạn, quà vĩnh viễn, thu hồi, nhật ký Access, xung đột Control và quyền RLS ghi hàng 1.

## Kiểm tra đã chạy

- Swift 6.2.3 parse toàn bộ tệp Swift. Sáu service được type-check và bốn kiểm thử đã chạy đạt trên Linux, dùng Swift Crypto thay CryptoKit và lớp tương thích tạm cho API riêng của Apple. Các lớp tương thích không nằm trong source iOS.
- Fixture gốc khớp từng byte khi chạy thuật toán trích từ HTML Vault và khi chạy triển khai Swift. Kiểm thử cũng kiểm tra SHA-256, UUID, giải mã với AAD, từ chối gói lỗi, payload Access và mã hóa query timestamp.
- Hai bộ kiểm thử JavaScript trong ZIP Dynor iOS chạy đạt. Đã kiểm tra cấu trúc YAML, cú pháp script build, các khóa bản dịch và tính toàn vẹn của ZIP.

## Sửa số tài khoản

Đã thêm kiểm thử cho trang API ngắn, trường total sai và UID trùng. Bộ kiểm thử mô phỏng trường hợp metadata báo 33 nhưng các trang trả về 61 tài khoản. Kiểm tra trực tiếp số liệu hiện tại cần phiên Admin của dự án.

## Nhập .tendies từ Tệp

Trong Vault, chọn **Nhập .tendies** và mở tệp. Bộ chọn iOS yêu cầu bản sao của
tài liệu trước khi Studio đọc và kiểm tra gói. Bạn cũng có thể nhấn giữ tệp
.tendies trong ứng dụng **Tệp**, chọn **Chia sẻ → Dynor Studio**. Nếu đang khóa
ứng dụng, tệp sẽ được nhập vào Vault sau khi mở khóa. Bản này có build 2.

Trong màn **Đăng hình nền** hoặc **Chỉnh sửa hình nền**, hai mục ảnh bìa
và video xem trước có thể chọn từ **Thư viện ảnh** hoặc **Tệp**. Ảnh và video
hiển thị bản xem trước sau khi nhập xong. Giới hạn mỗi ảnh hoặc video là 50 MiB.
