-- Apply only where an existing bucket is missing the equivalent Admin policies.
-- Review all other policies first. PostgreSQL combines permissive policies with OR.
-- Depends on the existing public.dynor_is_admin(). This script does not alter either bucket.
begin;

drop policy if exists "Dynor Studio Admin reads assets" on storage.objects;
create policy "Dynor Studio Admin reads assets" on storage.objects
  for select to authenticated
  using (bucket_id in ('dynor-wallpapers', 'dynor-downloads') and (select public.dynor_is_admin()));

drop policy if exists "Dynor Studio Admin uploads assets" on storage.objects;
create policy "Dynor Studio Admin uploads assets" on storage.objects
  for insert to authenticated
  with check (bucket_id in ('dynor-wallpapers', 'dynor-downloads')
              and (select public.dynor_is_admin()));

drop policy if exists "Dynor Studio Admin removes assets" on storage.objects;
create policy "Dynor Studio Admin removes assets" on storage.objects
  for delete to authenticated
  using (bucket_id in ('dynor-wallpapers', 'dynor-downloads') and (select public.dynor_is_admin()));

commit;
