import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct StudioDocumentPicker: UIViewControllerRepresentable {
    let contentTypes: [UTType]
    let onFinish: (URL?) -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        var identifiers = Set<String>()
        let candidates = (contentTypes + [.data, .item]).filter { identifiers.insert($0.identifier).inserted }
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: candidates, asCopy: true)
        picker.allowsMultipleSelection = false
        picker.shouldShowFileExtensions = true
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(onFinish: onFinish) }

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        private var onFinish: ((URL?) -> Void)?

        init(onFinish: @escaping (URL?) -> Void) { self.onFinish = onFinish }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            finish(urls.first)
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { finish(nil) }

        private func finish(_ url: URL?) {
            let callback = onFinish
            onFinish = nil
            callback?(url)
        }
    }
}
