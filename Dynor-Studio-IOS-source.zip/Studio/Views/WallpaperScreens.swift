import AVKit
import CoreTransferable
import ImageIO
import PhotosUI
import SwiftUI
import UniformTypeIdentifiers

struct WallListScreen: View {
    @Environment(StudioModel.self) private var model
    @State private var work = Work()
    @State private var rows: [Wallpaper] = []
    @State private var loaded = false
    @State private var search = ""
    @State private var tier: Tier?
    @State private var published: Bool?
    @State private var confirmAll = false
    @State private var repairIssues: [String] = []

    private var filtered: [Wallpaper] {
        rows.filter { wall in
            (tier == nil || wall.tier == tier) && (published == nil || wall.published == published)
                && (search.trimmed.isEmpty || [wall.title, wall.description, wall.category]
                    .contains { $0.localizedCaseInsensitiveContains(search.trimmed) })
        }
    }

    var body: some View {
        List {
            if work.busy || work.error != nil || work.notice != nil {
                Section { WorkStatus(work: work) { Task { await reload() } } }
            }
            if !repairIssues.isEmpty {
                Section(L10n.text("syncIssues")) {
                    ForEach(Array(repairIssues.enumerated()), id: \.offset) { _, issue in
                        Text(issue).textSelection(.enabled)
                    }
                }
            }
            if loaded && filtered.isEmpty {
                StudioEmpty(key: "noWallpapers", symbol: "photo.on.rectangle")
            }
            ForEach(filtered) { wall in
                NavigationLink {
                    WallpaperDetail(initial: wall)
                } label: {
                    HStack(spacing: 14) {
                        RemoteCover(raw: wall.cover).frame(width: 56, height: 66).clipShape(.rect(cornerRadius: 11))
                        VStack(alignment: .leading, spacing: 4) {
                            HStack { Text(wall.title).font(.headline); TierMark(tier: wall.tier) }
                            Text(wall.category).font(.subheadline).foregroundStyle(.secondary)
                            Text(L10n.text(wall.published ? "public" : "hidden"))
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
        .navigationTitle(L10n.text("wallpapers"))
        .searchable(text: $search, prompt: Text(L10n.text("wallSearch")))
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Picker(L10n.text("tier"), selection: $tier) {
                        Text(L10n.text("all")).tag(nil as Tier?)
                        ForEach(Tier.allCases) { tier in Text(L10n.text(tier.rawValue)).tag(tier as Tier?) }
                    }
                    Picker(L10n.text("visibility"), selection: $published) {
                        Text(L10n.text("all")).tag(nil as Bool?)
                        Text(L10n.text("public")).tag(true as Bool?)
                        Text(L10n.text("hidden")).tag(false as Bool?)
                    }
                    Button(L10n.text("reload"), systemImage: "arrow.clockwise") { Task { await reload() } }
                    Button(L10n.text("syncAll"), systemImage: "link") { confirmAll = true }.disabled(rows.isEmpty)
                } label: { Label(L10n.text("filter"), systemImage: "line.3.horizontal.decrease") }
                    .disabled(work.busy)
            }
            ToolbarItem(placement: .topBarTrailing) {
                Button(L10n.text("publish"), systemImage: "plus") { model.publish() }.disabled(work.busy)
            }
        }
        .refreshable { await reload() }
        .task(id: model.wallpaperRevision) { await reload() }
        .confirmationDialog(L10n.text("confirmSyncAll"), isPresented: $confirmAll, titleVisibility: .visible) {
            Button(L10n.text("syncAll")) { Task { await repair() } }
        }
    }

    private func reload() async {
        await work.run {
            rows = try await model.wallpapers.list()
            loaded = true
        }
    }

    private func repair() async {
        await work.run {
            repairIssues = []
            let current = try await model.wallpapers.list()
            rows = current
            work.progress = 0
            for (index, wall) in current.enumerated() {
                try Task.checkCancellation()
                do { _ = try await model.wallpapers.sync(wall) }
                catch { repairIssues.append(wall.title + " · " + error.localizedDescription) }
                work.progress = Double(index + 1) / Double(current.count)
            }
            if repairIssues.isEmpty { work.notice = L10n.text("synced") }
        }
    }
}

struct WallpaperDetail: View {
    @Environment(StudioModel.self) private var model
    @Environment(\.dismiss) private var dismiss
    @State private var work = Work()
    @State private var player: AVPlayer?
    @State private var confirmDelete = false
    @State private var confirmSync = false
    @State private var verified: PackageInfo?
    @State private var wall: Wallpaper
    @State private var deleted = false

    init(initial: Wallpaper) { _wall = State(initialValue: initial) }

    var body: some View {
        List {
            Section {
                RemoteCover(raw: wall.cover).frame(height: 250).clipShape(.rect(cornerRadius: 14))
                if let player {
                    VideoPlayer(player: player).frame(height: 230)
                } else if let video = wall.video, !video.isEmpty {
                    Button(L10n.text("playPreview"), systemImage: "play.circle") {
                        Task {
                            await work.run {
                                guard let url = await model.wallpapers.previewURL(video) else {
                                    throw StudioError.message("previewUnavailable")
                                }
                                let asset = AVURLAsset(url: url)
                                guard try await asset.load(.isPlayable) else {
                                    throw StudioError.message("previewUnavailable")
                                }
                                player = AVPlayer(playerItem: AVPlayerItem(asset: asset))
                                player?.play()
                            }
                        }
                    }
                }
            }
            Section {
                LabeledContent(L10n.text("tier")) {
                    HStack { TierMark(tier: wall.tier); Text(L10n.text(wall.tier?.rawValue ?? "unknownTier")) }
                }
                LabeledContent(L10n.text("visibility"), value: L10n.text(wall.published ? "public" : "hidden"))
                if !wall.category.isEmpty { LabeledContent(L10n.text("category"), value: wall.category) }
                if !wall.description.isEmpty { Text(wall.description) }
                if let name = wall.filename { LabeledContent(L10n.text("encryptedFile"), value: name) }
            }
            if let verified {
                Section(L10n.text("integrity")) {
                    Text(verified.id)
                    Text(verified.sha)
                }.font(.caption.monospaced()).textSelection(.enabled)
            }
            if !deleted {
                Section {
                    Button(L10n.text("syncPackage"), systemImage: "checkmark.shield") { confirmSync = true }
                    Button(L10n.text("deleteWallpaper"), systemImage: "trash", role: .destructive) { confirmDelete = true }
                }
            }
            if work.busy || work.error != nil || work.notice != nil { Section { WorkStatus(work: work) } }
        }
        .disabled(work.busy)
        .navigationTitle(wall.title)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            if !deleted {
                Button(L10n.text("edit")) { model.draft = WallpaperDraft(existing: wall) }.disabled(work.busy)
            }
        }
        .onDisappear { player?.pause() }
        .onChange(of: model.wallpaperRevision) { _, _ in
            if !deleted {
                Task {
                    await work.run {
                        guard let fresh = try await model.wallpapers.find(wall.id) else {
                            dismiss()
                            return
                        }
                        wall = fresh
                        verified = nil
                        player?.pause()
                        player = nil
                    }
                }
            }
        }
        .confirmationDialog(L10n.text("confirmDelete"), isPresented: $confirmDelete, titleVisibility: .visible) {
            Button(L10n.text("deleteWallpaper"), role: .destructive) {
                Task {
                    await work.run {
                        let cleaned = try await model.wallpapers.delete(wall)
                        deleted = true
                        model.wallpaperRevision += 1
                        if cleaned { dismiss() } else { work.notice = L10n.text("cleanupAfterSave") }
                    }
                }
            }
        }
        .confirmationDialog(L10n.text("confirmSync"), isPresented: $confirmSync, titleVisibility: .visible) {
            Button(L10n.text("syncPackage")) {
                Task {
                    await work.run {
                        verified = try await model.wallpapers.sync(wall)
                        work.notice = L10n.text("synced")
                    }
                }
            }
        }
    }
}

private enum AssetInput: String {
    case coverFile, previewFile, packageFile
    var contentTypes: [UTType] {
        switch self {
        case .coverFile: return [.image]
        case .previewFile: return [.movie]
        case .packageFile: return [.dynor]
        }
    }
}

private struct LibraryCover: Transferable {
    let file: StudioFile

    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(importedContentType: .image) { received in
            LibraryCover(file: try await StudioFile.imported(received.file, limit: PackageInfo.plainLimit))
        }
    }
}

private struct LibraryPreviewVideo: Transferable {
    let file: StudioFile

    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(importedContentType: .movie) { received in
            LibraryPreviewVideo(file: try await StudioFile.imported(received.file, limit: PackageInfo.plainLimit))
        }
    }
}

struct WallEditor: View {
    @Environment(StudioModel.self) private var model
    @Environment(\.dismiss) private var dismiss
    @State private var work = Work()
    @State private var draft: WallpaperDraft
    @State private var kind: AssetInput = .coverFile
    @State private var picking = false
    @State private var pickingPhotos = false
    @State private var photoItem: PhotosPickerItem?
    @State private var localCover: UIImage?
    @State private var localPlayer: AVPlayer?
    @State private var committed = false

    init(draft: WallpaperDraft) { _draft = State(initialValue: draft) }

    var body: some View {
        Form {
            Section(L10n.text("wallDetails")) {
                TextField(L10n.text("name"), text: $draft.title)
                TextField(L10n.text("description"), text: $draft.description, axis: .vertical).lineLimit(3...6)
                TextField(L10n.text("category"), text: $draft.category)
                Picker(L10n.text("tier"), selection: $draft.tier) {
                    if draft.tier == nil { Text(L10n.text("unknownTier")).tag(nil as Tier?) }
                    ForEach(Tier.allCases) { tier in Text(L10n.text(tier.rawValue)).tag(tier as Tier?) }
                }
                Toggle(L10n.text("public"), isOn: $draft.published)
            }.disabled(work.busy || committed)
            Section(L10n.text("wallFiles")) {
                if let localCover {
                    Image(uiImage: localCover).resizable().scaledToFit().frame(maxHeight: 180)
                } else if let cover = draft.existing?.cover {
                    RemoteCover(raw: cover).frame(height: 140).clipShape(.rect(cornerRadius: 12))
                }
                fileButton(.coverFile, file: draft.cover, fallback: nil, symbol: "photo")
                fileButton(.previewFile, file: draft.video, fallback: nil, symbol: "film")
                fileButton(.packageFile, file: draft.package, fallback: draft.existing?.filename, symbol: "lock.doc")
                if let localPlayer { VideoPlayer(player: localPlayer).frame(height: 170) }
            }.disabled(work.busy || committed)
            Section {
                WorkStatus(work: work)
                if !committed {
                    StudioAction(key: "save", symbol: "checkmark", primary: true) { Task { await save() } }
                        .disabled(work.busy || draft.title.trimmed.isEmpty || draft.tier == nil)
                }
            }
        }
        .navigationTitle(L10n.text(draft.existing == nil ? "publish" : "editWallpaper"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button(L10n.text(committed ? "done" : "cancel")) { dismiss() }.disabled(work.busy)
            }
        }
        .interactiveDismissDisabled(work.busy)
        .overlay {
            if model.privacyCover {
                Rectangle().fill(.background).ignoresSafeArea()
            }
        }
        .onDisappear { localPlayer?.pause() }
        .fileImporter(isPresented: $picking, allowedContentTypes: kind.contentTypes) { result in
            let requested = kind
            Task { await choose(result, kind: requested) }
        }
        .photosPicker(isPresented: $pickingPhotos, selection: $photoItem,
                      matching: kind == .coverFile ? .images : .videos,
                      preferredItemEncoding: .current)
        .onChange(of: photoItem) { _, item in
            guard let item else { return }
            let requested = kind
            photoItem = nil
            Task { await chooseFromPhotos(item, kind: requested) }
        }
    }

    private func fileButton(_ input: AssetInput, file: StudioFile?, fallback: String?, symbol: String) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            if input == .packageFile {
                Button(L10n.text(input.rawValue), systemImage: symbol) { kind = input; picking = true }
            } else {
                Menu {
                    Button(L10n.text("photoLibrary"), systemImage: "photo.on.rectangle") {
                        kind = input
                        pickingPhotos = true
                    }
                    Button(L10n.text("chooseFromFiles"), systemImage: "folder") {
                        kind = input
                        picking = true
                    }
                } label: {
                    Label(L10n.text(input.rawValue), systemImage: symbol)
                }
            }
            if let name = file?.name ?? fallback { Text(name).font(.caption).foregroundStyle(.secondary) }
        }
    }

    private func chooseFromPhotos(_ item: PhotosPickerItem, kind: AssetInput) async {
        await work.run {
            let file: StudioFile?
            switch kind {
            case .coverFile:
                file = try await item.loadTransferable(type: LibraryCover.self)?.file
            case .previewFile:
                file = try await item.loadTransferable(type: LibraryPreviewVideo.self)?.file
            case .packageFile: return
            }
            guard let file else { throw StudioError.message("fileUnreadable") }
            try await apply(file, kind: kind)
        }
    }

    private func choose(_ result: Result<URL, Error>, kind: AssetInput) async {
        await work.run {
            let url = try result.get()
            if kind == .packageFile && url.pathExtension.lowercased() != "dynor" {
                throw StudioError.message("invalidPackage")
            }
            let file = try await StudioFile.imported(url, limit: kind == .packageFile
                                                     ? PackageInfo.sealedLimit : PackageInfo.plainLimit)
            try await apply(file, kind: kind)
        }
    }

    private func apply(_ file: StudioFile, kind: AssetInput) async throws {
        switch kind {
        case .coverFile:
            guard let thumbnail = await Task.detached(priority: .userInitiated, operation: {
                guard let source = CGImageSourceCreateWithURL(file.url as CFURL, nil) else { return nil as CGImage? }
                return CGImageSourceCreateThumbnailAtIndex(source, 0, [
                    kCGImageSourceCreateThumbnailFromImageAlways: true,
                    kCGImageSourceCreateThumbnailWithTransform: true,
                    kCGImageSourceThumbnailMaxPixelSize: 800
                ] as CFDictionary)
            }).value else { throw StudioError.message("previewUnavailable") }
            localCover = UIImage(cgImage: thumbnail)
            draft.cover = file
        case .previewFile:
            let asset = AVURLAsset(url: file.url)
            guard try await asset.load(.isPlayable) else {
                throw StudioError.message("previewUnavailable")
            }
            localPlayer?.pause()
            localPlayer = AVPlayer(playerItem: AVPlayerItem(asset: asset))
            draft.video = file
        case .packageFile:
            draft.package = file
        }
    }

    private func save() async {
        await work.run {
            do {
                let cleaned = try await model.wallpapers.save(draft) { fraction in
                    await MainActor.run {
                        if work.busy { work.progress = max(work.progress ?? 0, fraction) }
                    }
                }
                committed = true
                model.wallpaperRevision += 1
                if cleaned { dismiss() }
                else { work.notice = L10n.text("cleanupAfterSave") }
            } catch StudioError.message("saveUncertain") {
                committed = true
                model.wallpaperRevision += 1
                throw StudioError.message("saveUncertain")
            }
        }
    }
}
