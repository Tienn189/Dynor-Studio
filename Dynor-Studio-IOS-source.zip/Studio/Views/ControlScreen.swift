import SwiftUI

struct ControlScreen: View {
    @Environment(StudioModel.self) private var model
    @State private var work = Work()
    @State private var config: ControlConfig?
    @State private var build = ""
    @State private var confirm = false
    @State private var needsReview = false

    var body: some View {
        Form {
            if config != nil {
                Group {
                    Section(L10n.text("systemState")) {
                        Toggle(L10n.text("maintenance"), isOn: flag(\.maintenance_enabled))
                        Toggle(L10n.text("forceUpdate"), isOn: flag(\.force_update))
                    }
                    Section(L10n.text("update")) {
                        TextField(L10n.text("latestVersion"), text: field(\.latest_version))
                        TextField(L10n.text("minBuild"), text: $build).keyboardType(.numberPad)
                        TextField(L10n.text("updateTitle"), text: field(\.update_title))
                        TextField(L10n.text("updateMessage"), text: field(\.update_message), axis: .vertical).lineLimit(2...5)
                        TextField(L10n.text("telegram"), text: field(\.telegram_url))
                            .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
                    }
                    Section(L10n.text("maintenance")) {
                        TextField(L10n.text("maintenanceTitle"), text: field(\.maintenance_title))
                        TextField(L10n.text("maintenanceMessage"), text: field(\.maintenance_message), axis: .vertical).lineLimit(2...5)
                        TextField(L10n.text("eta"), text: field(\.maintenance_eta))
                    }
                }.disabled(work.busy || needsReview)
                Section {
                    StudioAction(key: "saveControl", symbol: "checkmark", primary: true) { confirm = true }
                        .disabled(work.busy || needsReview)
                    if let config {
                        LabeledContent(L10n.text("lastSynced"), value: L10n.date(config.updated_at))
                            .font(.footnote).foregroundStyle(.secondary)
                    }
                }
            }
            Section {
                Button(L10n.text("reload"), systemImage: "arrow.clockwise") { Task { await load() } }.disabled(work.busy)
                WorkStatus(work: work)
            }
        }
        .navigationTitle(L10n.text("control"))
        .task { if config == nil { await load() } }
        .confirmationDialog(L10n.text("confirmControl"), isPresented: $confirm, titleVisibility: .visible) {
            Button(L10n.text("saveControl")) { Task { await save() } }
        } message: { Text(L10n.text("controlImpact")) }
    }

    private func field(_ key: WritableKeyPath<ControlConfig, String?>) -> Binding<String> {
        Binding(get: { config?[keyPath: key] ?? "" }, set: { config?[keyPath: key] = $0 })
    }

    private func flag(_ key: WritableKeyPath<ControlConfig, Bool>) -> Binding<Bool> {
        Binding(get: { config?[keyPath: key] ?? false }, set: { config?[keyPath: key] = $0 })
    }

    private func load() async {
        await work.run {
            let loaded = try await model.control.load()
            config = loaded
            build = String(loaded.minimum_build)
            needsReview = false
        }
    }

    private func save() async {
        await work.run {
            guard var candidate = config, let value = Int(build) else { throw StudioError.message("invalidBuild") }
            candidate.minimum_build = value
            do {
                let saved = try await model.control.save(candidate)
                config = saved
                build = String(saved.minimum_build)
                model.controlRevision += 1
                work.notice = L10n.text("saved")
            } catch StudioError.message("controlConflict") {
                needsReview = true
                throw StudioError.message("controlConflict")
            }
        }
    }
}
