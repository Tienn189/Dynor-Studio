import SwiftUI

struct UserListScreen: View {
    @Environment(StudioModel.self) private var model
    @State private var work = Work()
    @State private var searchWork = Work()
    @State private var search = ""
    @State private var page = 1
    @State private var searchPage = 1
    @State private var result: AccountPage?
    @State private var allAccounts: [Account]?

    private var searching: Bool { !search.trimmed.isEmpty }
    private var matches: [Account] {
        allAccounts?.filter { $0.email?.localizedCaseInsensitiveContains(search.trimmed) == true } ?? []
    }
    private var shown: [Account] {
        guard searching else { return result?.accounts ?? [] }
        return Array(matches.dropFirst((searchPage - 1) * AccessService.pageSize).prefix(AccessService.pageSize))
    }
    private var canAdvance: Bool {
        if searching { return searchPage * AccessService.pageSize < matches.count }
        if let total = result?.total { return page * AccessService.pageSize < total }
        return result?.accounts.count == AccessService.pageSize
    }

    var body: some View {
        List {
            if let focus = model.userFocus {
                Label(L10n.text(focus == .vip ? "chooseVIPAccount" : "chooseGiftAccount"), systemImage: "person.crop.circle")
            }
            Section {
                HStack {
                    Button(L10n.text("previous"), systemImage: "chevron.left") { step(-1) }
                        .labelStyle(.iconOnly).disabled((searching ? searchPage : page) <= 1)
                    Spacer()
                    Text(L10n.text("page") + " " + String(searching ? searchPage : page))
                        .font(.subheadline.monospacedDigit())
                    Spacer()
                    Button(L10n.text("next"), systemImage: "chevron.right") { step(1) }
                        .labelStyle(.iconOnly).disabled(!canAdvance)
                }.buttonStyle(.borderless).disabled(work.busy || searchWork.busy)
                if let total = searching ? allAccounts.map({ _ in matches.count }) : result?.total {
                    LabeledContent(L10n.text(searching ? "results" : "totalAccounts"), value: total.formatted())
                }
            }
            if work.busy || work.error != nil {
                Section { WorkStatus(work: work) { Task { await load(page) } } }
            }
            if searching && (searchWork.busy || searchWork.error != nil) {
                Section { WorkStatus(work: searchWork) { Task { await loadSearch() } } }
            }
            if shown.isEmpty && (searching ? allAccounts != nil : result != nil) {
                StudioEmpty(key: "noAccounts", symbol: "person.2")
            }
            ForEach(shown) { account in
                NavigationLink {
                    AccountScreen(initial: account, page: searching ? nil : page, focus: model.userFocus)
                } label: {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(account.email ?? account.id).font(.headline)
                        Text(L10n.text((account.quota?.active).map { $0 ? "vip" : "free" } ?? "unknown"))
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                }
            }
        }
        .navigationTitle(L10n.text("users"))
        .searchable(text: $search, prompt: Text(L10n.text("emailSearch")))
        .toolbar {
            NavigationLink { AuditScreen() } label: { Label(L10n.text("audit"), systemImage: "clock.arrow.circlepath") }
        }
        .task { if result == nil { await load(1) } }
        .onChange(of: search) { _, value in
            searchPage = 1
            if !value.trimmed.isEmpty && allAccounts == nil { Task { await loadSearch() } }
        }
        .onChange(of: model.accessRevision) { _, _ in
            allAccounts = nil
            Task {
                if searching { searchPage = 1; await loadSearch() }
                else { await load(page) }
            }
        }
        .refreshable {
            allAccounts = nil
            if searching { searchPage = 1; await loadSearch() }
            else { await load(page) }
        }
    }

    private func step(_ distance: Int) {
        if searching { searchPage += distance }
        else { Task { await load(page + distance) } }
    }

    private func load(_ requested: Int) async {
        await work.run {
            let response = try await model.access.list(page: requested)
            result = response
            page = requested
        }
    }

    private func loadSearch() async {
        await searchWork.run { allAccounts = try await model.access.allAccounts() }
    }
}

private struct PendingChange: Identifiable {
    let id = UUID()
    let title: String
    let change: AccountChange
    let destructive: Bool
}

struct AccountScreen: View {
    @Environment(StudioModel.self) private var model
    let page: Int?
    let focus: UserFocus?
    @State private var work = Work()
    @State private var account: Account
    @State private var gifts: [Gift]?
    @State private var wallpapers: [GrantWallpaper] = []
    @State private var plan: VIPPlan = .month
    @State private var days = "30"
    @State private var delta = "5"
    @State private var selectedWall: String?
    @State private var giftDays = "0"
    @State private var pending: PendingChange?
    @State private var needsReview = false

    init(initial: Account, page: Int?, focus: UserFocus?) {
        _account = State(initialValue: initial)
        self.page = page
        self.focus = focus
    }

    var body: some View {
        ScrollViewReader { proxy in
            Form {
                Section(L10n.text("account")) {
                    LabeledContent(L10n.text("email"), value: account.email ?? "—")
                    LabeledContent("UID", value: account.id)
                    LabeledContent(L10n.text("created"), value: L10n.date(account.created_at))
                    LabeledContent(L10n.text("lastLogin"), value: L10n.date(account.last_sign_in_at))
                    LabeledContent(L10n.text("vipStatus"), value: account.quota?.active.map {
                        L10n.text($0 ? "active" : "inactive")
                    } ?? "—")
                    LabeledContent(L10n.text("vipPlan"), value: displayedPlan)
                    LabeledContent(L10n.text("expires"), value: L10n.date(account.vip?.vip_expires_at))
                    LabeledContent(L10n.text("crownLeft"), value: account.quota?.unlimited == true
                        ? L10n.text("unlimited") : account.quota?.remaining?.formatted() ?? "—")
                }.textSelection(.enabled)

                if work.busy || work.error != nil || work.notice != nil {
                    Section { WorkStatus(work: work) { Task { await refreshAccount() } } }
                }

                Section(L10n.text("manageVIP")) {
                    Picker(L10n.text("vipPlan"), selection: $plan) {
                        ForEach(VIPPlan.allCases) { item in Text(L10n.text(item.rawValue)).tag(item) }
                    }
                    if plan != .lifetime {
                        TextField(L10n.text("durationDays"), text: $days).keyboardType(.numberPad)
                    }
                    Button(L10n.text("grantVIP"), systemImage: "person.badge.plus") {
                        ask("replaceVIP", .vip(plan: plan.rawValue, days: plan == .lifetime ? 0 : (Int(days) ?? 0)))
                    }.disabled(plan != .lifetime && (Int(days) ?? 0) <= 0)
                    Button(L10n.text("revokeVIP"), role: .destructive) { ask("confirmRevokeVIP", .revokeVIP, destructive: true) }
                }.id(UserFocus.vip).disabled(work.busy || needsReview)

                Section(L10n.text("crownCredits")) {
                    TextField(L10n.text("delta"), text: $delta).keyboardType(.numbersAndPunctuation)
                    Button(L10n.text("adjustCredits"), systemImage: "plus.forwardslash.minus") {
                        if let amount = Int(delta), amount != 0 { ask("confirmCredits", .credits(amount)) }
                    }.disabled((Int(delta) ?? 0) == 0)
                }.disabled(work.busy || needsReview)

                Section(L10n.text("grantWallpaper")) {
                    Picker(L10n.text("wallpapers"), selection: $selectedWall) {
                        Text(L10n.text("selectWallpaper")).tag(nil as String?)
                        ForEach(wallpapers) { wall in
                            HStack { Text(wall.title); TierMark(tier: wall.access_tier.flatMap(Tier.init(rawValue:))) }
                                .tag(wall.id as String?)
                        }
                    }
                    if let cover = wallpapers.first(where: { $0.id == selectedWall })?.image_url {
                        RemoteCover(raw: cover).frame(width: 86, height: 98).clipShape(.rect(cornerRadius: 12))
                    }
                    TextField(L10n.text("giftDuration"), text: $giftDays).keyboardType(.numberPad)
                    Button(L10n.text("grantWallpaper"), systemImage: "gift") {
                        if let id = selectedWall, let days = Int(giftDays), days >= 0 {
                            ask("confirmGift", .gift(wallpaper: id, days: days))
                        }
                    }.disabled(selectedWall == nil || (Int(giftDays) ?? -1) < 0)
                }.id(UserFocus.gift).disabled(work.busy || needsReview)

                Section(L10n.text("existingGifts")) {
                    if gifts?.isEmpty == true { Text(L10n.text("noGifts")).foregroundStyle(.secondary) }
                    ForEach(gifts ?? []) { gift in
                        VStack(alignment: .leading, spacing: 6) {
                            Text(gift.title).font(.headline)
                            Text(gift.expires_at.map { L10n.date($0) } ?? L10n.text("lifetime"))
                                .font(.caption).foregroundStyle(.secondary)
                            Button(L10n.text("revokeGift"), role: .destructive) {
                                ask("confirmRevokeGift", .revokeGift(gift.wallpaper_id), destructive: true)
                            }
                        }
                    }
                }.disabled(work.busy || needsReview)
            }
            .task {
                await work.run { try await loadOptions() }
                if let focus { withAnimation { proxy.scrollTo(focus, anchor: .top) } }
            }
        }
        .navigationTitle(account.email ?? account.id)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            Button(L10n.text("reload"), systemImage: "arrow.clockwise") { Task { await refreshAccount() } }
                .disabled(work.busy)
        }
        .onChange(of: plan) { _, newPlan in days = String(newPlan.days) }
        .confirmationDialog(pending?.title ?? "", isPresented: Binding(
            get: { pending != nil }, set: { if !$0 { pending = nil } }
        ), titleVisibility: .visible, presenting: pending) { request in
            Button(L10n.text("confirm"), role: request.destructive ? .destructive : nil) {
                Task { await apply(request.change) }
            }
        }
    }

    private var displayedPlan: String {
        guard let id = account.vip?.plan_id else { return L10n.text("free") }
        let key = ["weekly": "week", "monthly": "month", "quarterly": "quarter"][id] ?? id
        return L10n.text(key)
    }

    private func ask(_ key: String, _ change: AccountChange, destructive: Bool = false) {
        pending = PendingChange(title: L10n.text(key), change: change, destructive: destructive)
    }

    private func loadOptions() async throws {
        let target = account.id
        async let serverGifts = model.access.gifts(target)
        async let serverWallpapers = model.access.wallpapers()
        (gifts, wallpapers) = try await (serverGifts, serverWallpapers)
    }

    private func refreshAccount() async {
        await work.run {
            try await updateAccount()
            try await loadOptions()
            needsReview = false
        }
    }

    private func updateAccount() async throws {
        let id = account.id
        if let page {
            let batch = try await model.access.list(page: page)
            if let updated = batch.accounts.first(where: { $0.id == id }) {
                account = updated
                return
            }
        }
        guard let updated = try await model.access.allAccounts().first(where: { $0.id == id }) else {
            throw StudioError.message("accountMissing")
        }
        account = updated
    }

    private func apply(_ change: AccountChange) async {
        await work.run {
            do {
                try await model.access.change(change, target: account.id)
            } catch {
                if let status = (error as? StudioError)?.status, (400..<500).contains(status), status != 408 { throw error }
                needsReview = true
                throw StudioError.message("changeUncertain")
            }
            needsReview = true
            model.accessRevision += 1
            try await updateAccount()
            gifts = try await model.access.gifts(account.id)
            needsReview = false
            work.notice = L10n.text("saved")
        }
    }
}

struct AuditScreen: View {
    @Environment(StudioModel.self) private var model
    @State private var work = Work()
    @State private var rows: [AuditEntry]?

    var body: some View {
        List {
            if work.busy || work.error != nil { WorkStatus(work: work) { Task { await load() } } }
            if rows?.isEmpty == true { StudioEmpty(key: "noAudit", symbol: "clock.arrow.circlepath") }
            ForEach(Array((rows ?? []).enumerated()), id: \.offset) { _, entry in AuditRow(entry: entry) }
        }
        .navigationTitle(L10n.text("audit"))
        .task { if rows == nil { await load() } }
        .refreshable { await load() }
    }

    private func load() async {
        await work.run { rows = try await model.access.audit() }
    }
}
