import SwiftUI

struct UserListScreen: View {
    @Environment(StudioModel.self) private var model
    @State private var search = ""
    @State private var planFilter: AccountPlanFilter = .all
    @State private var page = 1

    var body: some View {
        let query = search.trimmed
        let matches = (model.accounts ?? []).filter {
            planFilter.includes($0) && (query.isEmpty || $0.email?.localizedCaseInsensitiveContains(query) == true)
        }
        let lastPage = max(1, (matches.count + AccessService.pageSize - 1) / AccessService.pageSize)
        let currentPage = min(page, lastPage)
        let shown = matches.dropFirst((currentPage - 1) * AccessService.pageSize).prefix(AccessService.pageSize)

        List {
            if let focus = model.userFocus {
                Label(L10n.text(focus == .vip ? "chooseVIPAccount" : "chooseGiftAccount"), systemImage: "person.crop.circle")
            }
            Section {
                Picker(selection: $planFilter) {
                    ForEach(AccountPlanFilter.options, id: \.self) { option in
                        Text(L10n.text(option.labelKey)).tag(option)
                    }
                } label: {
                    Label(L10n.text("filterVIP"), systemImage: "line.3.horizontal.decrease")
                }
                .pickerStyle(.menu)
                HStack {
                    Button(L10n.text("previous"), systemImage: "chevron.left") { page = currentPage - 1 }
                        .labelStyle(.iconOnly).disabled(currentPage <= 1)
                    Spacer()
                    Text(L10n.text("page") + " " + String(currentPage))
                        .font(.subheadline.monospacedDigit())
                    Spacer()
                    Button(L10n.text("next"), systemImage: "chevron.right") { page = currentPage + 1 }
                        .labelStyle(.iconOnly).disabled(currentPage >= lastPage)
                }.buttonStyle(.borderless).disabled(model.accountsWork.busy)
                if let accounts = model.accounts {
                    LabeledContent(L10n.text("totalAccounts"), value: accounts.count.formatted())
                    if !query.isEmpty || planFilter != .all {
                        LabeledContent(L10n.text("results"), value: matches.count.formatted())
                    }
                    LabeledContent(L10n.text("accountsOnPage"), value: shown.count.formatted())
                }
            }
            if model.accountsWork.busy || model.accountsWork.error != nil {
                Section { WorkStatus(work: model.accountsWork) { Task { await model.refreshAccounts() } } }
            }
            if shown.isEmpty && model.accounts != nil {
                StudioEmpty(key: "noAccounts", symbol: "person.2")
            }
            ForEach(shown) { account in
                NavigationLink {
                    AccountScreen(initial: account, focus: model.userFocus)
                } label: {
                    VStack(alignment: .leading, spacing: 5) {
                        Text(account.email ?? account.id).font(.headline)
                        Text(membershipLabel(for: account))
                            .font(.subheadline).foregroundStyle(.secondary)
                    }
                }
            }
        }
        .navigationTitle(L10n.text("users"))
        .searchable(text: $search, prompt: Text(L10n.text("emailSearch")))
        .toolbar {
            NavigationLink { AuditScreen() } label: { Label(L10n.text("audit"), systemImage: "clock.arrow.circlepath") }
        }
        .task { await model.refreshAccounts(force: false) }
        .onChange(of: search) { _, _ in page = 1 }
        .onChange(of: planFilter) { _, _ in page = 1 }
        .onChange(of: lastPage) { _, limit in page = min(page, limit) }
        .refreshable { await model.refreshAccounts() }
    }

    private func membershipLabel(for account: Account) -> String {
        let key: String
        switch account.vipStatus {
        case .active: key = "vip"
        case .inactive: key = "vipInactive"
        case .free: return L10n.text("free")
        case .unknown: return L10n.text("unknown")
        }
        let status = L10n.text(key)
        guard let id = account.vip?.plan_id, let plan = VIPPlan(serverID: id) else { return status }
        return status + " · " + L10n.text(plan.rawValue)
    }
}

private struct PendingChange: Identifiable {
    let id = UUID()
    let title: String
    let change: AccountChange
    let destructive: Bool
}

struct AccountScreen: View {
    @Environment(StudioModel.self) private var model
    let focus: UserFocus?
    @State private var work = Work()
    @State private var account: Account
    @State private var gifts: [Gift]?
    @State private var wallpapers: [GrantWallpaper] = []
    @State private var plan: VIPPlan = .month
    @State private var days = "30"
    @State private var delta = "5"
    @State private var selectedWall: String?
    @State private var showingWallpaperPicker = false
    @State private var giftDays = "0"
    @State private var pending: PendingChange?
    @State private var needsReview = false

    init(initial: Account, focus: UserFocus?) {
        _account = State(initialValue: initial)
        self.focus = focus
    }

    private var selectedWallpaper: GrantWallpaper? {
        wallpapers.first { $0.id == selectedWall }
    }

    var body: some View {
        ScrollViewReader { proxy in
            Form {
                Section(L10n.text("account")) {
                    LabeledContent(L10n.text("email"), value: account.email ?? "—")
                    LabeledContent("UID", value: account.id)
                    LabeledContent(L10n.text("created"), value: L10n.date(account.created_at))
                    LabeledContent(L10n.text("lastLogin"), value: L10n.date(account.last_sign_in_at))
                    LabeledContent(L10n.text("vipStatus"), value: account.quota?.active.map {
                        L10n.text($0 ? "active" : "inactive")
                    } ?? "—")
                    LabeledContent(L10n.text("vipPlan"), value: displayedPlan)
                    LabeledContent(L10n.text("expires"), value: L10n.date(account.vip?.vip_expires_at))
                    LabeledContent(L10n.text("crownLeft"), value: account.quota?.unlimited == true
                        ? L10n.text("unlimited") : account.quota?.remaining?.formatted() ?? "—")
                }.textSelection(.enabled)

                if work.busy || work.error != nil || work.notice != nil {
                    Section { WorkStatus(work: work) { Task { await refreshAccount() } } }
                }

                Section(L10n.text("manageVIP")) {
                    Picker(L10n.text("vipPlan"), selection: $plan) {
                        ForEach(VIPPlan.allCases) { item in Text(L10n.text(item.rawValue)).tag(item) }
                    }
                    if plan != .lifetime {
                        TextField(L10n.text("durationDays"), text: $days).keyboardType(.numberPad)
                    }
                    Button(L10n.text("grantVIP"), systemImage: "person.badge.plus") {
                        ask("replaceVIP", .vip(plan: plan.rawValue, days: plan == .lifetime ? 0 : (Int(days) ?? 0)))
                    }.disabled(plan != .lifetime && (Int(days) ?? 0) <= 0)
                    Button(L10n.text("revokeVIP"), role: .destructive) { ask("confirmRevokeVIP", .revokeVIP, destructive: true) }
                }.id(UserFocus.vip).disabled(work.busy || needsReview)

                Section(L10n.text("crownCredits")) {
                    TextField(L10n.text("delta"), text: $delta).keyboardType(.numbersAndPunctuation)
                    Button(L10n.text("adjustCredits"), systemImage: "plus.forwardslash.minus") {
                        if let amount = Int(delta), amount != 0 { ask("confirmCredits", .credits(amount)) }
                    }.disabled((Int(delta) ?? 0) == 0)
                }.disabled(work.busy || needsReview)

                Section(L10n.text("grantWallpaper")) {
                    Button {
                        showingWallpaperPicker = true
                    } label: {
                        HStack(spacing: 12) {
                            if let selectedWallpaper {
                                GiftWallpaperTitle(wallpaper: selectedWallpaper)
                            } else {
                                Text(L10n.text("selectWallpaper"))
                            }
                            Spacer(minLength: 8)
                            Image(systemName: "chevron.right")
                                .font(.footnote.weight(.semibold))
                                .foregroundStyle(.tertiary)
                                .accessibilityHidden(true)
                        }
                        .contentShape(Rectangle())
                    }.buttonStyle(.plain)
                    if let cover = selectedWallpaper?.image_url {
                        RemoteCover(raw: cover).frame(width: 86, height: 98).clipShape(.rect(cornerRadius: 12))
                    }
                    TextField(L10n.text("giftDuration"), text: $giftDays).keyboardType(.numberPad)
                    Button(L10n.text("grantWallpaper"), systemImage: "gift") {
                        if let selectedWallpaper, let days = Int(giftDays), days >= 0 {
                            ask("confirmGift", .gift(wallpaper: selectedWallpaper.id, days: days))
                        }
                    }.disabled(selectedWallpaper == nil || (Int(giftDays) ?? -1) < 0)
                }.id(UserFocus.gift).disabled(work.busy || needsReview)

                Section(L10n.text("existingGifts")) {
                    if gifts?.isEmpty == true { Text(L10n.text("noGifts")).foregroundStyle(.secondary) }
                    ForEach(gifts ?? []) { gift in
                        VStack(alignment: .leading, spacing: 6) {
                            Text(gift.title).font(.headline)
                            Text(gift.expires_at.map { L10n.date($0) } ?? L10n.text("lifetime"))
                                .font(.caption).foregroundStyle(.secondary)
                            Button(L10n.text("revokeGift"), role: .destructive) {
                                ask("confirmRevokeGift", .revokeGift(gift.wallpaper_id), destructive: true)
                            }
                        }
                    }
                }.disabled(work.busy || needsReview)
            }
            .task {
                await work.run { try await loadOptions() }
                if let focus { withAnimation { proxy.scrollTo(focus, anchor: .top) } }
            }
        }
        .navigationTitle(account.email ?? account.id)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            Button(L10n.text("reload"), systemImage: "arrow.clockwise") { Task { await refreshAccount() } }
                .disabled(work.busy)
        }
        .onChange(of: plan) { _, newPlan in days = String(newPlan.days) }
        .sheet(isPresented: $showingWallpaperPicker) {
            GiftWallpaperPicker(wallpapers: wallpapers, selection: $selectedWall)
        }
        .confirmationDialog(pending?.title ?? "", isPresented: Binding(
            get: { pending != nil }, set: { if !$0 { pending = nil } }
        ), titleVisibility: .visible, presenting: pending) { request in
            Button(L10n.text("confirm"), role: request.destructive ? .destructive : nil) {
                Task { await apply(request.change) }
            }
        }
    }

    private var displayedPlan: String {
        guard let id = account.vip?.plan_id else { return L10n.text("free") }
        return L10n.text(VIPPlan(serverID: id)?.rawValue ?? id)
    }

    private func ask(_ key: String, _ change: AccountChange, destructive: Bool = false) {
        pending = PendingChange(title: L10n.text(key), change: change, destructive: destructive)
    }

    private func loadOptions() async throws {
        let target = account.id
        async let serverGifts = model.access.gifts(target)
        async let serverWallpapers = model.access.wallpapers()
        (gifts, wallpapers) = try await (serverGifts, serverWallpapers)
    }

    private func refreshAccount() async {
        await work.run {
            try await updateAccount()
            try await loadOptions()
            needsReview = false
        }
    }

    private func updateAccount() async throws {
        let id = account.id
        guard let updated = try await model.loadAccounts(force: true).first(where: { $0.id == id }) else {
            throw StudioError.message("accountMissing")
        }
        account = updated
    }

    private func apply(_ change: AccountChange) async {
        await work.run {
            do {
                try await model.access.change(change, target: account.id)
            } catch {
                if let status = (error as? StudioError)?.status, (400..<500).contains(status), status != 408 { throw error }
                needsReview = true
                throw StudioError.message("changeUncertain")
            }
            needsReview = true
            model.accountAccessChanged()
            try await updateAccount()
            gifts = try await model.access.gifts(account.id)
            needsReview = false
            work.notice = L10n.text("saved")
        }
    }
}

private struct GiftWallpaperTitle: View {
    let wallpaper: GrantWallpaper

    var body: some View {
        HStack(spacing: 8) {
            Text(wallpaper.title)
                .fixedSize(horizontal: false, vertical: true)
            TierMark(tier: wallpaper.access_tier.flatMap(Tier.init(rawValue:)))
        }
        .accessibilityElement(children: .combine)
    }
}

private struct GiftWallpaperPicker: View {
    @Environment(\.dismiss) private var dismiss
    let wallpapers: [GrantWallpaper]
    @Binding var selection: String?
    @State private var search = ""

    private var filtered: [GrantWallpaper] {
        let query = search.trimmed
        guard !query.isEmpty else { return wallpapers }
        return wallpapers.filter { $0.title.localizedStandardContains(query) }
    }

    var body: some View {
        let results = filtered
        NavigationStack {
            List {
                ForEach(results) { wallpaper in
                    Button {
                        selection = wallpaper.id
                        dismiss()
                    } label: {
                        HStack(spacing: 12) {
                            GiftWallpaperTitle(wallpaper: wallpaper)
                            Spacer(minLength: 8)
                            if selection == wallpaper.id {
                                Image(systemName: "checkmark")
                                    .font(.body.weight(.semibold))
                                    .foregroundStyle(Color.accentColor)
                                    .accessibilityHidden(true)
                            }
                        }
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .accessibilityAddTraits(selection == wallpaper.id ? .isSelected : [])
                }
            }
            .overlay {
                if results.isEmpty {
                    StudioEmpty(key: "noWallpapers", symbol: "photo.on.rectangle")
                }
            }
            .navigationTitle(L10n.text("selectWallpaper"))
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $search, placement: .navigationBarDrawer(displayMode: .always),
                        prompt: Text(L10n.text("wallSearch")))
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(L10n.text("cancel")) { dismiss() }
                }
            }
        }
    }
}

struct AuditScreen: View {
    @Environment(StudioModel.self) private var model
    @State private var work = Work()
    @State private var rows: [AuditEntry]?

    var body: some View {
        List {
            if work.busy || work.error != nil { WorkStatus(work: work) { Task { await load() } } }
            if rows?.isEmpty == true { StudioEmpty(key: "noAudit", symbol: "clock.arrow.circlepath") }
            ForEach(Array((rows ?? []).enumerated()), id: \.offset) { _, entry in AuditRow(entry: entry) }
        }
        .navigationTitle(L10n.text("audit"))
        .task { if rows == nil { await load() } }
        .refreshable { await load() }
    }

    private func load() async {
        await work.run { rows = try await model.access.audit() }
    }
}
