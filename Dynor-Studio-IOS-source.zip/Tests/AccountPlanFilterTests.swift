import XCTest
@testable import DynorStudio

final class AccountPlanFilterTests: XCTestCase {
    func testSpecificPlansMatchActiveAccountsAndLegacyPlanIDs() {
        XCTAssertTrue(AccountPlanFilter.plan(.week).includes(account(plan: "week", active: true)))
        XCTAssertTrue(AccountPlanFilter.plan(.month).includes(account(plan: "monthly", active: true)))
        XCTAssertTrue(AccountPlanFilter.plan(.quarter).includes(account(plan: "quarterly", active: true)))
        XCTAssertTrue(AccountPlanFilter.plan(.lifetime).includes(account(plan: "lifetime", active: true)))
        XCTAssertFalse(AccountPlanFilter.plan(.month).includes(account(plan: "monthly", active: false)))
        XCTAssertFalse(AccountPlanFilter.plan(.week).includes(account(plan: "month", active: true)))
    }

    func testActiveInactiveFreeAndUnknownStayDistinct() {
        let active = account(plan: nil, active: true)
        let inactive = account(plan: "month", active: false)
        let free = account(plan: nil, active: false)
        let unknown = account(plan: "week", active: nil)

        XCTAssertTrue(AccountPlanFilter.active.includes(active))
        XCTAssertTrue(AccountPlanFilter.inactive.includes(inactive))
        XCTAssertFalse(AccountPlanFilter.free.includes(inactive))
        XCTAssertTrue(AccountPlanFilter.free.includes(free))
        XCTAssertTrue(AccountPlanFilter.all.includes(unknown))
        XCTAssertFalse(AccountPlanFilter.active.includes(unknown))
        XCTAssertFalse(AccountPlanFilter.inactive.includes(unknown))
        XCTAssertFalse(AccountPlanFilter.free.includes(unknown))
    }

    private func account(plan: String?, active: Bool?) -> Account {
        Account(id: "id", email: nil, created_at: nil, last_sign_in_at: nil,
                vip: plan.map { .init(plan_id: $0, vip_expires_at: nil) },
                quota: .init(active: active, unlimited: nil, remaining: nil))
    }
}
