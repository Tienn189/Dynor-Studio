import Foundation

struct ControlConfig: Decodable, Sendable {
    let id: Int
    var maintenance_enabled: Bool
    var force_update: Bool
    var minimum_build: Int
    var latest_version: String?
    var update_title: String?
    var update_message: String?
    var telegram_url: String?
    var maintenance_title: String?
    var maintenance_message: String?
    var maintenance_eta: String?
    let updated_at: String
}

struct ControlService: Sendable {
    let auth: AuthService
    private let api = APIClient()
    private let path = "rest/v1/dynor_app_control"
    private let row = URLQueryItem(name: "id", value: "eq.1")

    func load() async throws -> ControlConfig {
        let token = try await auth.authorized().token
        let (data, _) = try await api.call(path, token: token, query: [row, .init(name: "select", value: "*")])
        guard let config = try api.decode([ControlConfig].self, data).first else {
            throw StudioError.message("controlMissing")
        }
        return config
    }

    func save(_ config: ControlConfig) async throws -> ControlConfig {
        guard (1...Int(Int32.max)).contains(config.minimum_build) else {
            throw StudioError.message("invalidBuild")
        }
        let telegram = config.telegram_url?.trimmed ?? ""
        if !telegram.isEmpty {
            guard let url = URL(string: telegram), url.scheme?.lowercased() == "https", url.host != nil else {
                throw StudioError.message("invalidTelegram")
            }
        }
        let body: JSONObject = [
            "maintenance_enabled": .bool(config.maintenance_enabled), "force_update": .bool(config.force_update),
            "minimum_build": .number(Double(config.minimum_build)), "telegram_url": .string(telegram),
            "latest_version": .string(config.latest_version?.trimmed ?? ""),
            "update_title": .string(config.update_title?.trimmed ?? ""),
            "update_message": .string(config.update_message?.trimmed ?? ""),
            "maintenance_title": .string(config.maintenance_title?.trimmed ?? ""),
            "maintenance_message": .string(config.maintenance_message?.trimmed ?? ""),
            "maintenance_eta": .string(config.maintenance_eta?.trimmed ?? ""),
            "updated_at": .string(ISO8601DateFormatter().string(from: Date()))
        ]
        let token = try await auth.authorized().token
        let (data, _) = try await api.call(path, method: "PATCH", token: token,
            query: [row, .init(name: "updated_at", value: "eq." + config.updated_at), .init(name: "select", value: "*")],
            body: body, headers: ["Prefer": "return=representation"])
        guard let result = try api.decode([ControlConfig].self, data).first else {
            throw StudioError.message("controlConflict")
        }
        return result
    }
}
