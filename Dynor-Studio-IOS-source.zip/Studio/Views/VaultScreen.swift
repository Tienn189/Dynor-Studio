import CoreTransferable
import Observation
import SwiftUI
import UIKit
import UniformTypeIdentifiers

private struct VaultExport: Transferable {
    let file: StudioFile
    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(exportedContentType: .dynor) { item in SentTransferredFile(item.file.url) }
    }
}

@MainActor
@Observable
final class VaultState {
    let work = Work()
    var source: StudioFile?
    var encrypted: StudioFile?
    var tier: Tier = .free
    private(set) var importing = false

    func importPackage(_ candidate: URL) async {
        await work.run {
            importing = true
            defer { importing = false }
            source = try await VaultService.importTendies(candidate)
            encrypted = nil
        }
    }
}

private struct TendiesDocumentPicker: UIViewControllerRepresentable {
    let onFinish: (URL?) -> Void

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let declared = UTType.types(tag: "tendies", tagClass: .filenameExtension, conformingTo: nil)
        var identifiers = Set<String>()
        let contentTypes = ([UTType.tendies] + declared + [.data]).filter {
            identifiers.insert($0.identifier).inserted
        }
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: contentTypes, asCopy: false)
        picker.allowsMultipleSelection = false
        picker.shouldShowFileExtensions = true
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}

    func makeCoordinator() -> Coordinator { Coordinator(onFinish: onFinish) }

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        private var onFinish: ((URL?) -> Void)?

        init(onFinish: @escaping (URL?) -> Void) { self.onFinish = onFinish }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            finish(urls.first)
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { finish(nil) }

        private func finish(_ url: URL?) {
            let callback = onFinish
            onFinish = nil
            callback?(url)
        }
    }
}

struct VaultScreen: View {
    @Environment(StudioModel.self) private var model
    @State private var imports = false
    @State private var export = false

    var body: some View {
        @Bindable var state = model.vaultState
        let work = state.work
        List {
            Section {
                Label(L10n.text("vaultNote"), systemImage: "shield.lefthalf.filled")
                    .font(.subheadline).foregroundStyle(.secondary)
                Button { imports = true } label: { Label(L10n.text("importTendies"), systemImage: "folder") }
                if state.importing {
                    ProgressView(L10n.text("vaultImportReading"))
                }
                if let source = state.source {
                    LabeledContent {
                        VStack(alignment: .trailing, spacing: 3) {
                            Text(source.name).lineLimit(2)
                            Text(ByteCountFormatter.string(fromByteCount: Int64(source.size), countStyle: .file))
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    } label: { Text(L10n.text("sourceFile")) }
                    Button(L10n.text("removeFile"), role: .destructive) {
                        state.source = nil
                        state.encrypted = nil
                        work.error = nil
                        work.notice = nil
                    }
                }
                Picker(L10n.text("tier"), selection: $state.tier) {
                    ForEach(Tier.allCases) { tier in Text(L10n.text(tier.rawValue)).tag(tier) }
                }
                Text(L10n.text(state.tier.rawValue + "Hint")).font(.footnote).foregroundStyle(.secondary)
            }
            Section {
                StudioAction(key: "encrypt", symbol: "lock.fill", primary: true) { Task { await encrypt(state) } }
                    .disabled(state.source == nil)
            }.listRowBackground(Color.clear)
            if let encrypted = state.encrypted {
                Section(L10n.text("encryptedFile")) {
                    Text(encrypted.name)
                    ShareLink(item: encrypted.url) {
                        Label(L10n.text("share"), systemImage: "square.and.arrow.up")
                    }
                    Button { export = true } label: { Label(L10n.text("exportFile"), systemImage: "folder") }
                    Button { model.publish(encrypted, tier: state.tier) } label: {
                        Label(L10n.text("publish"), systemImage: "arrow.up.circle")
                    }
                }
            }
            if !state.importing && (work.busy || work.error != nil || work.notice != nil) {
                Section { WorkStatus(work: work) }
            }
        }
        .disabled(work.busy)
        .navigationTitle("Vault")
        .onChange(of: state.tier) { _, _ in state.encrypted = nil }
        .sheet(isPresented: $imports) {
            TendiesDocumentPicker { candidate in
                imports = false
                guard let candidate else { return }
                Task { await state.importPackage(candidate) }
            }
        }
        .fileExporter(isPresented: $export, item: state.encrypted.map { VaultExport(file: $0) }, contentTypes: [.dynor],
                      defaultFilename: state.encrypted?.url.deletingPathExtension().lastPathComponent) { result in
            Task {
                await work.run {
                    _ = try result.get()
                    work.notice = L10n.text("exported")
                }
            }
        }
    }

    private func encrypt(_ state: VaultState) async {
        guard let source = state.source else { return }
        let work = state.work
        await work.run {
            state.encrypted = nil
            state.encrypted = try await model.vault.encrypt(source, tier: state.tier) { fraction in
                await MainActor.run { if work.busy { work.progress = fraction } }
            }
            work.notice = L10n.text("registered")
        }
    }
}
