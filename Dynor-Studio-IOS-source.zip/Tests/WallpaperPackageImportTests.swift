import Foundation
import XCTest
@testable import DynorStudio

final class WallpaperPackageImportTests: XCTestCase {
    func testPublishingImportsDynorAndKeepsTheOriginalFile() async throws {
        let bytes = PackageInfo.magic + Data(repeating: 0, count: 64)
        let original = try makeDocument(name: "Batman.DYNOR", bytes: bytes)
        defer { try? FileManager.default.removeItem(at: original.deletingLastPathComponent()) }

        let imported = try await WallpaperService.importPackage(original)

        XCTAssertEqual(imported.name, "Batman.DYNOR")
        XCTAssertEqual(imported.size, bytes.count)
        XCTAssertNotEqual(imported.url, original)
        XCTAssertEqual(try Data(contentsOf: imported.url), bytes)
        XCTAssertEqual(try Data(contentsOf: original), bytes)
    }

    func testPublishingRejectsWrongExtensionAndTruncatedEnvelope() async throws {
        let archive = try makeDocument(name: "Batman.tendies", bytes: PackageInfo.magic + Data(repeating: 0, count: 64))
        let truncated = try makeDocument(name: "Batman.dynor", bytes: PackageInfo.magic)
        defer {
            for file in [archive, truncated] {
                try? FileManager.default.removeItem(at: file.deletingLastPathComponent())
            }
        }

        for file in [archive, truncated] {
            do {
                _ = try await WallpaperService.importPackage(file)
                XCTFail("Only .dynor files with a complete envelope can be selected for publishing.")
            } catch StudioError.message("invalidPackage") {}
        }
    }

    private func makeDocument(name: String, bytes: Data) throws -> URL {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: false)
        let file = directory.appendingPathComponent(name)
        try bytes.write(to: file)
        return file
    }
}
