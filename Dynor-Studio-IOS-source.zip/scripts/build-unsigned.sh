#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
output="${1:-$root/build/ipa}"
mkdir -p "$output"
output="$(cd "$output" && pwd)"
cd "$root"

major="$(xcrun --sdk iphoneos --show-sdk-version | cut -d. -f1)"
if [[ ! "$major" =~ ^[0-9]+$ ]] || (( major < 26 )); then
  echo "Xcode with the iOS 26 SDK or newer is required." >&2
  exit 1
fi
command -v xcodegen > /dev/null || { echo "Install XcodeGen with brew install xcodegen." >&2; exit 1; }

stage="$(mktemp -d)"
trap 'rm -rf "$stage"' EXIT

xcodegen generate --spec project.yml
xcodebuild -project DynorStudio.xcodeproj -scheme DynorStudio -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' \
  -derivedDataPath "$stage/DerivedData" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" build
app="$stage/DerivedData/Build/Products/Release-iphoneos/DynorStudio.app"
test -f "$app/DynorStudio"
test "$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$app/Info.plist")" = com.dynor.studio
test ! -d "$app/_CodeSignature"
test ! -f "$app/embedded.mobileprovision"
mkdir -p "$stage/Payload"
ditto "$app" "$stage/Payload/DynorStudio.app"
(
  cd "$stage"
  zip -q -r -y Dynor-Studio-unsigned.ipa Payload
  unzip -tq Dynor-Studio-unsigned.ipa
)
mv "$stage/Dynor-Studio-unsigned.ipa" "$output/Dynor-Studio-unsigned.ipa"
