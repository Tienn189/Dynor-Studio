import Foundation

struct Account: Decodable, Identifiable, Sendable {
    enum VIPStatus {
        case active, inactive, free, unknown
    }

    struct VIP: Decodable, Sendable {
        let plan_id: String?
        let vip_expires_at: String?
    }

    struct Quota: Decodable, Sendable {
        let active: Bool?
        let unlimited: Bool?
        let remaining: Int?
    }

    let id: String
    let email: String?
    let created_at: String?
    let last_sign_in_at: String?
    let vip: VIP?
    let quota: Quota?

    var vipStatus: VIPStatus {
        guard let active = quota?.active else { return .unknown }
        if active { return .active }
        let planID = vip?.plan_id?.trimmed.lowercased().nonEmpty
        let hasPlan = planID.map { $0 != "free" } ?? false
        return hasPlan || vip?.vip_expires_at?.trimmed.nonEmpty != nil ? .inactive : .free
    }
}

struct AccountPage: Decodable, Sendable {
    let accounts: [Account]
}

struct Gift: Decodable, Identifiable, Sendable {
    struct WallpaperTitle: Decodable, Sendable { let title: String? }
    let wallpaper_id: String
    let expires_at: String?
    let dynor_wallpapers: WallpaperTitle?
    var id: String { wallpaper_id }
    var title: String { dynor_wallpapers?.title ?? wallpaper_id }
}

struct AuditEntry: Decodable, Sendable {
    let created_at: String?
    let action: String
    let actor: String?
    let target: String?
}

struct GrantWallpaper: Decodable, Identifiable, Sendable {
    let id: String
    let title: String
    let image_url: String?
    let access_tier: String?
}

enum VIPPlan: String, CaseIterable, Identifiable {
    case week, month, quarter, lifetime

    init?(serverID: String) {
        switch serverID.trimmed.lowercased() {
        case "week", "weekly": self = .week
        case "month", "monthly": self = .month
        case "quarter", "quarterly": self = .quarter
        case "lifetime": self = .lifetime
        default: return nil
        }
    }

    var id: String { rawValue }
    var days: Int {
        switch self {
        case .week: return 7
        case .month: return 30
        case .quarter: return 90
        case .lifetime: return 0
        }
    }
}

enum AccountPlanFilter: Hashable {
    case all, active, inactive, free, plan(VIPPlan)

    static let options: [Self] = [.all, .active] + VIPPlan.allCases.map(Self.plan) + [.inactive, .free]

    var labelKey: String {
        switch self {
        case .all: return "all"
        case .active: return "vipActive"
        case .inactive: return "vipInactive"
        case .free: return "free"
        case .plan(let plan): return plan.rawValue
        }
    }

    func includes(_ account: Account) -> Bool {
        switch self {
        case .all: return true
        case .active: return account.vipStatus == .active
        case .inactive: return account.vipStatus == .inactive
        case .free: return account.vipStatus == .free
        case .plan(let plan):
            return account.vipStatus == .active && account.vip?.plan_id.flatMap(VIPPlan.init(serverID:)) == plan
        }
    }
}

enum AccountChange: Sendable {
    case vip(plan: String, days: Int)
    case revokeVIP
    case credits(Int)
    case gift(wallpaper: String, days: Int)
    case revokeGift(String)

    var payload: (String, JSONObject) {
        switch self {
        case .vip(let plan, let days): return ("vip", ["plan": .string(plan), "days": .number(Double(days))])
        case .revokeVIP: return ("revoke_vip", [:])
        case .credits(let delta): return ("credits", ["delta": .number(Double(delta))])
        case .gift(let id, let days): return ("gift", ["wallpaper_id": .string(id), "days": .number(Double(days))])
        case .revokeGift(let id): return ("revoke_gift", ["wallpaper_id": .string(id)])
        }
    }
}

struct AccessService: Sendable {
    let auth: AuthService
    private let api = APIClient()
    static let pageSize = 50

    private func invoke(_ action: String, fields: JSONObject = [:]) async throws -> Data {
        let token = try await auth.authorized().token
        var body = fields
        body["action"] = .string(action)
        let (data, _) = try await api.call("functions/v1/dynor-access", method: "POST", token: token, body: body)
        return data
    }

    func list(page: Int) async throws -> AccountPage {
        try await api.decode(AccountPage.self, invoke("list", fields: ["page": .number(Double(page))]))
    }

    func allAccounts() async throws -> [Account] {
        try await Self.collectAccounts { try await list(page: $0) }
    }

    static func collectAccounts(
        fetchPage: (Int) async throws -> AccountPage
    ) async throws -> [Account] {
        var page = 1
        var rows: [Account] = []
        var ids = Set<String>()
        while true {
            try Task.checkCancellation()
            let batch = try await fetchPage(page).accounts
            if batch.isEmpty { return rows }
            // The response's total is not used to terminate or count the directory.
            guard batch.allSatisfy({ ids.insert($0.id).inserted }) else {
                throw StudioError.message("accountsChanged")
            }
            rows += batch
            page += 1
        }
    }

    func wallpapers() async throws -> [GrantWallpaper] {
        try await api.decode([GrantWallpaper].self, invoke("wallpapers"))
    }

    func gifts(_ target: String) async throws -> [Gift] {
        try await api.decode([Gift].self, invoke("gifts", fields: ["target": .string(target)]))
    }

    func audit() async throws -> [AuditEntry] {
        try await api.decode([AuditEntry].self, invoke("audit"))
    }

    func change(_ change: AccountChange, target: String) async throws {
        let (action, data) = change.payload
        _ = try await invoke(action, fields: ["target": .string(target), "data": .object(data)])
    }
}
