import Foundation

enum StudioError: Error, LocalizedError {
    case message(String)
    case http(Int, String)
    case denied
    case expired

    var errorDescription: String? {
        switch self {
        case .message(let key): return L10n.text(key)
        case .http(let status, let message): return "HTTP \(status) · \(message)"
        case .denied: return L10n.text("adminDenied")
        case .expired: return L10n.text("sessionExpired")
        }
    }

    var status: Int? {
        if case .http(let code, _) = self { return code }
        return nil
    }
}

enum JSONValue: Codable, Sendable {
    case string(String), number(Double), bool(Bool), object([String: JSONValue]), array([JSONValue]), null

    init(from decoder: Decoder) throws {
        let value = try decoder.singleValueContainer()
        if value.decodeNil() { self = .null }
        else if let result = try? value.decode(Bool.self) { self = .bool(result) }
        else if let result = try? value.decode(Double.self) { self = .number(result) }
        else if let result = try? value.decode(String.self) { self = .string(result) }
        else if let result = try? value.decode([String: JSONValue].self) { self = .object(result) }
        else { self = .array(try value.decode([JSONValue].self)) }
    }

    func encode(to encoder: Encoder) throws {
        var value = encoder.singleValueContainer()
        switch self {
        case .null: try value.encodeNil()
        case .string(let item): try value.encode(item)
        case .number(let item): try value.encode(item)
        case .bool(let item): try value.encode(item)
        case .object(let item): try value.encode(item)
        case .array(let item): try value.encode(item)
        }
    }

    static func optional(_ value: String?) -> Self { value.map(Self.string) ?? .null }
    var string: String? { if case .string(let value) = self { return value }; return nil }
    var bool: Bool? { if case .bool(let value) = self { return value }; return nil }
}

typealias JSONObject = [String: JSONValue]
typealias ProgressUpdate = @Sendable (Double) async -> Void

final class NoRedirect: NSObject, URLSessionTaskDelegate, Sendable {
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        completionHandler(nil)
    }
}

final class UploadObserver: NSObject, URLSessionTaskDelegate, Sendable {
    let progress: ProgressUpdate
    init(_ progress: @escaping ProgressUpdate) { self.progress = progress }
    func urlSession(_ session: URLSession, task: URLSessionTask,
                    didSendBodyData bytesSent: Int64, totalBytesSent: Int64, totalBytesExpectedToSend: Int64) {
        guard totalBytesExpectedToSend > 0 else { return }
        let fraction = min(1, Double(totalBytesSent) / Double(totalBytesExpectedToSend))
        Task { await progress(fraction) }
    }
}

struct APIClient: Sendable {
    static let base = URL(string: "https://wkivekbodwbinmvargts.supabase.co")!
    static let publishableKey = "sb_publishable_7eP5C7X8t6ip2ntFANmGJQ_K1Mybu2m"
    static let session: URLSession = {
        let settings = URLSessionConfiguration.ephemeral
        settings.httpShouldSetCookies = false
        settings.urlCache = nil
        settings.requestCachePolicy = .reloadIgnoringLocalCacheData
        settings.timeoutIntervalForRequest = 60
        settings.timeoutIntervalForResource = 300
        return URLSession(configuration: settings, delegate: NoRedirect(), delegateQueue: nil)
    }()

    static func url(_ path: String, query: [URLQueryItem] = []) -> URL {
        var parts = URLComponents(url: base, resolvingAgainstBaseURL: false)!
        parts.path = "/" + path
        if !query.isEmpty {
            parts.queryItems = query
            parts.percentEncodedQuery = parts.percentEncodedQuery?.replacingOccurrences(of: "+", with: "%2B")
        }
        return parts.url!
    }

    func request(_ path: String, method: String = "GET", token: String? = nil,
                 query: [URLQueryItem] = [], body: JSONObject? = nil,
                 headers: [String: String] = [:]) throws -> URLRequest {
        var request = URLRequest(url: Self.url(path, query: query))
        request.httpMethod = method
        request.setValue(Self.publishableKey, forHTTPHeaderField: "apikey")
        if let token { request.setValue("Bearer " + token, forHTTPHeaderField: "Authorization") }
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if let body {
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = try JSONEncoder().encode(body)
        }
        for (key, value) in headers { request.setValue(value, forHTTPHeaderField: key) }
        return request
    }

    func call(_ path: String, method: String = "GET", token: String? = nil,
              query: [URLQueryItem] = [], body: JSONObject? = nil,
              headers: [String: String] = [:], privateBody: Bool = false) async throws -> (Data, HTTPURLResponse) {
        let request = try request(path, method: method, token: token, query: query, body: body, headers: headers)
        let (bytes, response) = try await Self.session.data(for: request)
        return (bytes, try checked(response, bytes, privateBody: privateBody))
    }

    func upload(_ path: String, token: String, file: URL, mime: String,
                progress: @escaping ProgressUpdate) async throws {
        let request = try request(path, method: "POST", token: token,
                                  headers: ["Content-Type": mime, "x-upsert": "false"])
        let (data, response) = try await Self.session.upload(for: request, fromFile: file,
                                                            delegate: UploadObserver(progress))
        _ = try checked(response, data)
    }

    func checked(_ response: URLResponse, _ data: Data, privateBody: Bool = false) throws -> HTTPURLResponse {
        guard let http = response as? HTTPURLResponse else { throw StudioError.message("invalidResponse") }
        guard (200..<300).contains(http.statusCode) else {
            let object = privateBody ? nil : (try? JSONDecoder().decode(JSONObject.self, from: data))
            let message = object?["message"]?.string ?? object?["error_description"]?.string
                ?? object?["error"]?.string ?? object?["msg"]?.string
            throw StudioError.http(http.statusCode, message ?? L10n.text("requestFailed"))
        }
        return http
    }

    func decode<T: Decodable>(_ type: T.Type, _ bytes: Data) throws -> T {
        do { return try JSONDecoder().decode(type, from: bytes) }
        catch { throw StudioError.message("invalidResponse") }
    }
}

extension String {
    var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) }
    var nonEmpty: String? { isEmpty ? nil : self }
}
