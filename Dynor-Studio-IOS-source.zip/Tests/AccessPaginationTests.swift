import Foundation
import XCTest
@testable import DynorStudio

final class AccessPaginationTests: XCTestCase {
    func testCountsReturnedAccountsDespiteStaleTotalsAndShortPages() async throws {
        let pages = [
            try response(0..<33, reportedTotal: 33),
            try response(33..<61, reportedTotal: 33),
            try response(61..<61, reportedTotal: 33)
        ]
        var fetched: [Int] = []
        let accounts = try await AccessService.collectAccounts { page in
            fetched.append(page)
            return pages[page - 1]
        }

        XCTAssertEqual(fetched, [1, 2, 3])
        XCTAssertEqual(accounts.count, 61)
        XCTAssertEqual(accounts.first?.id, "account-0")
        XCTAssertEqual(accounts.last?.id, "account-60")
    }

    func testRepeatedAccountPageFailsInsteadOfCountingTwice() async throws {
        let page = try response(0..<33, reportedTotal: 61)
        do {
            _ = try await AccessService.collectAccounts { _ in page }
            XCTFail("A repeated page must not produce a total.")
        } catch StudioError.message("accountsChanged") {
            // The caller can retry the directory scan against a fresh server view.
        }
    }

    func testEmptyDirectoryReturnsZeroEvenWithIncorrectTotal() async throws {
        let empty = try response(0..<0, reportedTotal: 33)
        let accounts = try await AccessService.collectAccounts { _ in empty }
        XCTAssertTrue(accounts.isEmpty)
    }

    private func response(_ ids: Range<Int>, reportedTotal: Int) throws -> AccountPage {
        let accounts = ids.map { ["id": "account-\($0)"] }
        let bytes = try JSONSerialization.data(withJSONObject: ["accounts": accounts, "total": reportedTotal])
        return try JSONDecoder().decode(AccountPage.self, from: bytes)
    }
}
