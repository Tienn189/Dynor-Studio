import Foundation
import XCTest
@testable import DynorStudio

final class VaultDocumentRoutingTests: XCTestCase {
    @MainActor
    func testFileOpensInVaultAfterAdminUnlock() async throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: false)
        defer { try? FileManager.default.removeItem(at: directory) }
        let file = directory.appendingPathComponent("Batman.tendies")
        try Data([0x50, 0x4b, 3, 4, 1, 2]).write(to: file)

        let model = StudioModel()
        model.receiveVaultDocument(file)
        XCTAssertNil(model.readyVaultDocumentID)

        model.admin = AdminUser(id: UUID(), email: nil)
        model.locked = true
        await model.importPendingVaultDocument()
        XCTAssertNil(model.vaultState.source)

        model.locked = false
        XCTAssertNotNil(model.readyVaultDocumentID)
        await model.importPendingVaultDocument()

        XCTAssertEqual(model.tab, .vault)
        XCTAssertEqual(model.vaultState.source?.name, file.lastPathComponent)
        XCTAssertNil(model.readyVaultDocumentID)
    }
}
