-- Read-only inspection. Compare results with the deployed Admin/Access contract.
select to_regclass('public.dynor_admins') as admins,
       to_regclass('public.dynor_wallpapers') as wallpapers,
       to_regclass('public.dynor_app_control') as app_control;

select n.nspname as schema_name, p.proname, pg_get_function_identity_arguments(p.oid) as arguments,
       p.prosecdef as security_definer
from pg_proc p
join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public' and p.proname in ('dynor_admin_save_wallpaper', 'dynor_is_admin');

select id, public, file_size_limit, allowed_mime_types
from storage.buckets where id in ('dynor-wallpapers', 'dynor-downloads');

select schemaname, tablename, policyname, roles, cmd, qual, with_check
from pg_policies
where (schemaname = 'public' and tablename in ('dynor_admins','dynor_wallpapers','dynor_app_control'))
   or (schemaname = 'storage' and tablename = 'objects')
order by schemaname, tablename, policyname;

select table_schema, table_name, grantee, privilege_type
from information_schema.role_table_grants
where table_schema = 'public' and table_name = 'dynor_app_control';
