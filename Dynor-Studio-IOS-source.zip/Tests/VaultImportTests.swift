import Foundation
import XCTest
@testable import DynorStudio

final class VaultImportTests: XCTestCase {
    func testImportsTendiesAndPreservesTheOriginal() async throws {
        let file = try makeFile(named: "Batman.TENDIES", bytes: Data([0x50, 0x4b, 3, 4, 1, 2]))
        defer { try? FileManager.default.removeItem(at: file.deletingLastPathComponent()) }

        let result = try await VaultService.importTendies(file)

        XCTAssertEqual(result.name, "Batman.TENDIES")
        XCTAssertEqual(result.size, 6)
        XCTAssertNotEqual(result.url, file)
        XCTAssertEqual(try Data(contentsOf: result.url), try Data(contentsOf: file))
    }

    func testRejectsEncryptedFilesAndInvalidArchiveHeaders() async throws {
        let validHeader = Data([0x50, 0x4b, 3, 4])
        let encrypted = try makeFile(named: "Batman.dynor", bytes: validHeader)
        let corrupt = try makeFile(named: "Batman.tendies", bytes: Data([1, 2, 3, 4]))
        defer {
            try? FileManager.default.removeItem(at: encrypted.deletingLastPathComponent())
            try? FileManager.default.removeItem(at: corrupt.deletingLastPathComponent())
        }

        do {
            _ = try await VaultService.importTendies(encrypted)
            XCTFail("An encrypted package should not enter the Tendies import flow.")
        } catch StudioError.message("vaultImportType") {}
        do {
            _ = try await VaultService.importTendies(corrupt)
            XCTFail("A file without a ZIP header should not be selectable for encryption.")
        } catch StudioError.message("invalidTendies") {}
    }

    func testImportEnforcesSizeLimit() async throws {
        let file = try makeFile(named: "Batman.tendies", bytes: Data(repeating: 7, count: 129))
        defer { try? FileManager.default.removeItem(at: file.deletingLastPathComponent()) }
        do {
            _ = try await StudioFile.imported(file, limit: 128)
            XCTFail("The staged copy must respect the caller's byte limit.")
        } catch StudioError.message("fileSize") {}
    }

    private func makeFile(named name: String, bytes: Data) throws -> URL {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: false)
        let file = directory.appendingPathComponent(name)
        try bytes.write(to: file)
        return file
    }
}
