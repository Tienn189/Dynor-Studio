import CryptoKit
import Darwin
import Foundation
import UniformTypeIdentifiers

extension UTType {
    static let tendies = UTType(importedAs: "com.dynor.tendies")
    static let dynor = UTType(importedAs: "com.dynor.encrypted-wallpaper")
}

enum Tier: String, CaseIterable, Identifiable, Sendable {
    case free, premium, crown
    var id: String { rawValue }
    var symbol: String? {
        switch self {
        case .free: return nil
        case .premium: return "diamond.fill"
        case .crown: return "crown.fill"
        }
    }
}

final class StudioFile: Sendable {
    let url: URL
    let size: Int
    var name: String { url.lastPathComponent }
    private let directory: URL

    private init(url: URL, size: Int, directory: URL) {
        self.url = url
        self.size = size
        self.directory = directory
    }

    deinit { try? FileManager.default.removeItem(at: directory) }

    private static func workspace() throws -> URL {
        let directory = FileManager.default.temporaryDirectory
            .appendingPathComponent("Studio-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: false,
                                                attributes: [.protectionKey: FileProtectionType.complete])
        return directory
    }

    static func imported(_ source: URL, limit: Int, requiredExtension: String? = nil) async throws -> StudioFile {
        try await Task.detached(priority: .userInitiated) {
            guard source.isFileURL else { throw StudioError.message("fileUnreadable") }
            let scoped = source.startAccessingSecurityScopedResource()
            defer { if scoped { source.stopAccessingSecurityScopedResource() } }
            let metadata = try? source.resourceValues(forKeys: [.nameKey, .isUbiquitousItemKey])
            if metadata?.isUbiquitousItem == true {
                try? FileManager.default.startDownloadingUbiquitousItem(at: source)
            }
            let directory = try workspace()
            do {
                var readError: NSError?
                var result: Result<StudioFile, Error>?
                NSFileCoordinator().coordinate(readingItemAt: source, options: [], error: &readError) { readable in
                    result = Result {
                        let coordinatedName = try? readable.resourceValues(forKeys: [.nameKey]).name
                        let names = [source.lastPathComponent, metadata?.name, coordinatedName, readable.lastPathComponent]
                            .compactMap { $0 }
                        let name = try preferredFilename(names, requiredExtension: requiredExtension)
                        let destination = directory.appendingPathComponent(name, isDirectory: false)
                        let size = try copy(from: readable, to: destination, limit: limit)
                        return StudioFile(url: destination, size: size, directory: directory)
                    }
                }
                if let readError { throw readError }
                guard let result else { throw StudioError.message("fileUnreadable") }
                return try result.get()
            } catch {
                try? FileManager.default.removeItem(at: directory)
                throw error
            }
        }.value
    }

    private static func preferredFilename(_ candidates: [String], requiredExtension: String?) throws -> String {
        let names = candidates.filter { name in
            !name.trimmed.isEmpty && name != "." && name != ".." &&
            !name.contains("/") && !name.contains("\\") && !name.contains("\0")
        }
        if let requiredExtension {
            guard let matched = names.first(where: { ($0 as NSString).pathExtension.lowercased() == requiredExtension }) else {
                throw StudioError.message("vaultImportType")
            }
            return matched
        }
        return names.first { !(($0 as NSString).pathExtension.isEmpty) } ?? names.first ?? "document"
    }

    private static func copy(from source: URL, to destination: URL, limit: Int) throws -> Int {
        let input = try FileHandle(forReadingFrom: source)
        defer { try? input.close() }
        var attributes = stat()
        guard fstat(input.fileDescriptor, &attributes) == 0 else {
            throw POSIXError(POSIXErrorCode(rawValue: errno) ?? .EIO)
        }
        // File providers may omit URL metadata even when a coordinated file is ready to read.
        guard attributes.st_mode & mode_t(S_IFMT) == mode_t(S_IFREG), attributes.st_size <= Int64(limit) else {
            throw StudioError.message("fileSize")
        }
        guard FileManager.default.createFile(atPath: destination.path, contents: nil, attributes: [
            .protectionKey: FileProtectionType.complete, .posixPermissions: 0o600
        ]) else { throw StudioError.message("fileUnreadable") }
        let output = try FileHandle(forWritingTo: destination)
        defer { try? output.close() }
        var size = 0
        while let chunk = try input.read(upToCount: 64 * 1024), !chunk.isEmpty {
            guard chunk.count <= limit - size else { throw StudioError.message("fileSize") }
            try output.write(contentsOf: chunk)
            size += chunk.count
        }
        guard size > 0 else { throw StudioError.message("fileSize") }
        return size
    }

    static func generated(_ bytes: Data, name: String) throws -> StudioFile {
        let directory = try workspace()
        do {
            let url = directory.appendingPathComponent(name)
            try bytes.write(to: url, options: [.atomic, .completeFileProtection])
            return StudioFile(url: url, size: bytes.count, directory: directory)
        } catch {
            try? FileManager.default.removeItem(at: directory)
            throw error
        }
    }
}

struct PackageInfo: Sendable {
    static let magic = Data("DYNORT01".utf8)
    static let plainLimit = 50 * 1024 * 1024
    static let overhead = 52
    static let sealedLimit = plainLimit + overhead

    let id: String
    let sha: String

    init(_ bytes: Data) throws {
        guard bytes.count > Self.overhead, bytes.count <= Self.sealedLimit, bytes.starts(with: Self.magic) else {
            throw StudioError.message("invalidPackage")
        }
        let uuid = Array(bytes.dropFirst(8).prefix(16))
        id = UUID(uuid: (uuid[0], uuid[1], uuid[2], uuid[3], uuid[4], uuid[5], uuid[6], uuid[7],
                         uuid[8], uuid[9], uuid[10], uuid[11], uuid[12], uuid[13], uuid[14], uuid[15]))
            .uuidString.lowercased()
        sha = SHA256.hash(data: bytes).map { String(format: "%02x", $0) }.joined()
    }
}

struct VaultService: Sendable {
    let auth: AuthService
    private let api = APIClient()

    static func importTendies(_ url: URL) async throws -> StudioFile {
        let source = try await StudioFile.imported(url, limit: PackageInfo.plainLimit, requiredExtension: "tendies")
        try validateTendiesFilename(source)
        try await Task.detached(priority: .userInitiated) {
            let handle = try FileHandle(forReadingFrom: source.url)
            defer { try? handle.close() }
            guard let prefix = try handle.read(upToCount: 4), hasZIPHeader(prefix) else {
                throw StudioError.message("invalidTendies")
            }
        }.value
        return source
    }

    static func seal(_ plaintext: Data, id: UUID, key: SymmetricKey,
                     nonce: AES.GCM.Nonce) throws -> Data {
        guard (4...PackageInfo.plainLimit).contains(plaintext.count),
              hasZIPHeader(plaintext),
              key.bitCount == 256 else {
            throw StudioError.message("invalidTendies")
        }
        var uuid = id.uuid
        var header = PackageInfo.magic
        withUnsafeBytes(of: &uuid) { header.append(contentsOf: $0) }
        let box = try AES.GCM.seal(plaintext, using: key, nonce: nonce, authenticating: header)
        guard let combined = box.combined else { throw StudioError.message("invalidPackage") }
        header.append(combined)
        return header
    }

    private static func hasZIPHeader(_ bytes: Data) -> Bool {
        bytes.starts(with: [0x50, 0x4b, 0x03, 0x04]) || bytes.starts(with: [0x50, 0x4b, 0x05, 0x06])
    }

    private static func validateTendiesFilename(_ source: StudioFile) throws {
        guard source.url.pathExtension.lowercased() == "tendies",
              (9...255).contains(source.name.unicodeScalars.count), source.name == source.name.trimmed,
              !source.name.unicodeScalars.contains(where: { $0.value < 32 || $0.value == 127 || $0 == "/" || $0 == "\\" }),
              source.size <= PackageInfo.plainLimit else {
            throw StudioError.message("invalidTendies")
        }
    }

    func encrypt(_ source: StudioFile, tier: Tier, progress: @escaping ProgressUpdate) async throws -> StudioFile {
        try Self.validateTendiesFilename(source)
        _ = try await auth.authorized()
        let key = SymmetricKey(size: .bits256)
        let encrypted = try await Task.detached(priority: .userInitiated) {
            await progress(0.15)
            var plaintext = try Data(contentsOf: source.url)
            defer { plaintext.resetBytes(in: 0..<plaintext.count) }
            await progress(0.35)
            let bytes = try Self.seal(plaintext, id: UUID(), key: key, nonce: AES.GCM.Nonce())
            return (bytes, try PackageInfo(bytes))
        }.value
        try Task.checkCancellation()
        let info = encrypted.1
        await progress(0.7)
        let token = try await auth.authorized().token
        var keyBytes = key.withUnsafeBytes { Data($0) }
        defer { keyBytes.resetBytes(in: 0..<keyBytes.count) }
        let (data, _) = try await api.call("functions/v1/dynor-register-package", method: "POST", token: token,
             body: ["package_id": .string(info.id), "sha256": .string(info.sha),
                    "key_base64": .string(keyBytes.base64EncodedString()), "original_name": .string(source.name),
                    "requires_vip": .bool(tier != .free), "access_tier": .string(tier.rawValue)], privateBody: true)
        let receipt = try api.decode(JSONObject.self, data)
        guard receipt["package_id"]?.string == info.id, receipt["sha256"]?.string == info.sha else {
            throw StudioError.message("registrationMismatch")
        }
        let output = try await Task.detached {
            let basename = source.url.deletingPathExtension().lastPathComponent
            return try StudioFile.generated(encrypted.0, name: (basename.nonEmpty ?? "wallpaper") + ".dynor")
        }.value
        await progress(1)
        return output
    }
}
