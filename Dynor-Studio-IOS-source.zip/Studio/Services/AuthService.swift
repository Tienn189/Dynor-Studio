import Foundation
import Security

struct AdminUser: Codable, Sendable {
    let id: UUID
    let email: String?
}

private struct AuthTokens: Codable, Sendable {
    let access_token: String
    let refresh_token: String
    let expires_in: Double
    let expires_at: Double?
    let user: AdminUser
}

private struct StoredSession: Codable, Sendable {
    let tokens: AuthTokens
    let expires: Date
}

private enum SessionKeychain {
    static let query: [String: Any] = [
        kSecClass as String: kSecClassGenericPassword,
        kSecAttrService as String: "com.dynor.studio.auth",
        kSecAttrAccount as String: "admin"
    ]

    static func load() throws -> StoredSession? {
        var request = query
        request[kSecReturnData as String] = true
        request[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        let status = SecItemCopyMatching(request as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = result as? Data else { throw StudioError.message("keychainError") }
        return try JSONDecoder().decode(StoredSession.self, from: data)
    }

    static func save(_ session: StoredSession) throws {
        let bytes = try JSONEncoder().encode(session)
        let attributes = [kSecValueData as String: bytes]
        var result = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if result == errSecItemNotFound {
            var item = query
            item[kSecValueData as String] = bytes
            item[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
            result = SecItemAdd(item as CFDictionary, nil)
        }
        guard result == errSecSuccess else { throw StudioError.message("keychainError") }
    }

    static func clear() throws {
        let result = SecItemDelete(query as CFDictionary)
        guard result == errSecSuccess || result == errSecItemNotFound else {
            throw StudioError.message("keychainError")
        }
    }
}

actor AuthService {
    private let api = APIClient()
    private var session: StoredSession?
    private var restored = false
    private var generation = 0
    private var refresh: Task<StoredSession, Error>?

    func restore() async throws -> AdminUser? {
        if !restored {
            session = try SessionKeychain.load()
            restored = true
        }
        guard session != nil else { return nil }
        return try await authorized().user
    }

    func sendOTP(email: String) async throws {
        guard email.contains("@") else { throw StudioError.message("invalidEmail") }
        _ = try await api.call("auth/v1/otp", method: "POST",
                               body: ["email": .string(email), "create_user": .bool(false)])
    }

    func verify(email: String, otp: String) async throws -> AdminUser {
        try await signIn("auth/v1/verify", body: ["email": .string(email), "token": .string(otp), "type": .string("email")])
    }

    func password(email: String, password: String) async throws -> AdminUser {
        try await signIn("auth/v1/token", query: [.init(name: "grant_type", value: "password")],
                         body: ["email": .string(email), "password": .string(password)])
    }

    private func signIn(_ path: String, query: [URLQueryItem] = [], body: JSONObject) async throws -> AdminUser {
        let epoch = generation
        let (bytes, _) = try await api.call(path, method: "POST", query: query, body: body, privateBody: true)
        let candidate = makeSession(try api.decode(AuthTokens.self, bytes))
        try await checkAdmin(candidate.tokens)
        guard generation == epoch else { throw StudioError.expired }
        try SessionKeychain.save(candidate)
        session = candidate
        restored = true
        return candidate.tokens.user
    }

    func authorized() async throws -> (token: String, user: AdminUser) {
        let epoch = generation
        let current = try await validSession()
        do {
            try await checkAdmin(current.tokens)
        } catch let error as StudioError where error.status == 401 {
            guard generation == epoch else { throw StudioError.expired }
            let renewed = try await validSession(rejectedToken: current.tokens.access_token)
            do { try await checkAdmin(renewed.tokens) }
            catch {
                try invalidateIfDenied(error, epoch: epoch)
                throw error
            }
            guard generation == epoch else { throw StudioError.expired }
            return (renewed.tokens.access_token, renewed.tokens.user)
        } catch {
            try invalidateIfDenied(error, epoch: epoch)
            throw error
        }
        guard generation == epoch else { throw StudioError.expired }
        return (current.tokens.access_token, current.tokens.user)
    }

    private func invalidateIfDenied(_ error: Error, epoch: Int) throws {
        guard generation == epoch else { throw StudioError.expired }
        guard let error = error as? StudioError else { return }
        if case .denied = error { try clearLocal(); throw StudioError.denied }
        if error.status == 403 { try clearLocal(); throw StudioError.denied }
        if error.status == 401 { try clearLocal(); throw StudioError.expired }
    }

    private func checkAdmin(_ tokens: AuthTokens) async throws {
        let (data, _) = try await api.call("rest/v1/dynor_admins", token: tokens.access_token, query: [
            .init(name: "select", value: "user_id"),
            .init(name: "user_id", value: "eq." + tokens.user.id.uuidString.lowercased()),
            .init(name: "limit", value: "1")
        ])
        let rows = try api.decode([JSONObject].self, data)
        guard let id = rows.first?["user_id"]?.string, UUID(uuidString: id) == tokens.user.id else {
            throw StudioError.denied
        }
    }

    private func makeSession(_ tokens: AuthTokens) -> StoredSession {
        let expires = tokens.expires_at.map { Date(timeIntervalSince1970: $0) }
            ?? Date().addingTimeInterval(tokens.expires_in)
        return StoredSession(tokens: tokens, expires: expires)
    }

    private func validSession(rejectedToken: String? = nil) async throws -> StoredSession {
        guard let current = session else { throw StudioError.expired }
        if current.expires.timeIntervalSinceNow > 60, current.tokens.access_token != rejectedToken { return current }
        if let refresh { return try await refresh.value }
        let epoch = generation
        let task = Task<StoredSession, Error> {
            defer { if generation == epoch { refresh = nil } }
            do {
                let (bytes, _) = try await api.call("auth/v1/token", method: "POST",
                    query: [.init(name: "grant_type", value: "refresh_token")],
                    body: ["refresh_token": .string(current.tokens.refresh_token)], privateBody: true)
                let next = makeSession(try api.decode(AuthTokens.self, bytes))
                guard generation == epoch, next.tokens.user.id == current.tokens.user.id else {
                    throw StudioError.expired
                }
                session = next
                try SessionKeychain.save(next)
                return next
            } catch let error as StudioError where [400, 401, 403].contains(error.status ?? 0) {
                if generation == epoch { try clearLocal() }
                throw StudioError.expired
            }
        }
        refresh = task
        return try await task.value
    }

    private func clearLocal() throws {
        generation += 1
        session = nil
        restored = true
        refresh?.cancel()
        refresh = nil
        try SessionKeychain.clear()
    }

    func signOut() async throws {
        let token = session?.tokens.access_token
        try clearLocal()
        if let token {
            do {
                _ = try await api.call("auth/v1/logout", method: "POST", token: token,
                                       query: [.init(name: "scope", value: "local")])
            } catch let error as StudioError where error.status == 401 || error.status == 403 {
                return
            }
        }
    }
}
