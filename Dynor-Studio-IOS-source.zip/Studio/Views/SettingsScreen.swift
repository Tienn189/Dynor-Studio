import SwiftUI
import UIKit

struct SettingsScreen: View {
    @Environment(StudioModel.self) private var model
    @AppStorage(L10n.languageKey) private var language = "system"
    @AppStorage("studio.appearance") private var appearance = "system"
    @AppStorage("studio.accent") private var accent = "D6A93F"
    @AppStorage("studio.faceid") private var faceID = false
    @State private var work = Work()
    @State private var confirmLogout = false

    var body: some View {
        Form {
            Section(L10n.text("adminAccount")) {
                LabeledContent(L10n.text("email"), value: model.admin?.email ?? "—")
                LabeledContent("UID", value: model.admin?.id.uuidString.lowercased() ?? "—")
                Toggle("Face ID", isOn: Binding(get: { faceID }, set: { enabled in
                    Task {
                        await work.run {
                            try await model.authenticateFace()
                            faceID = enabled
                        }
                    }
                })).disabled(work.busy)
                WorkStatus(work: work)
            }
            Section(L10n.text("appearance")) {
                Picker(L10n.text("language"), selection: $language) {
                    Text(L10n.text("system")).tag("system")
                    Text("Tiếng Việt").tag("vi")
                    Text("English").tag("en")
                    Text("简体中文").tag("zh-Hans")
                }
                Picker(L10n.text("displayMode"), selection: $appearance) {
                    Text(L10n.text("system")).tag("system")
                    Text(L10n.text("light")).tag("light")
                    Text(L10n.text("dark")).tag("dark")
                }
                ColorPicker(L10n.text("theme"), selection: Binding(get: { Color(studioHex: accent) },
                    set: { if let hex = $0.studioHex { accent = hex } }), supportsOpacity: false)
                if accent != "D6A93F" {
                    Button(L10n.text("resetTheme")) { accent = "D6A93F" }
                }
            }
            Section(L10n.text("systemState")) {
                NavigationLink { ControlScreen() } label: { Label(L10n.text("control"), systemImage: "switch.2") }
                NavigationLink { AuditScreen() } label: {
                    Label(L10n.text("audit"), systemImage: "clock.arrow.circlepath")
                }
                LabeledContent("Supabase", value: L10n.text(model.online.map { $0 ? "connected" : "unreachable" } ?? "checking"))
                Button(L10n.text("checkConnection"), systemImage: "network") { Task { await model.recheck() } }
            }
            Section(L10n.text("device")) {
                LabeledContent(L10n.text("device"), value: UIDevice.current.model)
                LabeledContent("iOS", value: UIDevice.current.systemVersion)
                LabeledContent(L10n.text("version"), value: [
                    Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String,
                    Bundle.main.object(forInfoDictionaryKey: "DynorReleaseLabel") as? String
                ].compactMap { $0 }.joined(separator: " "))
                LabeledContent("Build", value: Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as? String ?? "—")
                LabeledContent("Bundle ID", value: Bundle.main.bundleIdentifier ?? "—")
            }
            Section {
                Button(L10n.text("signOut"), systemImage: "rectangle.portrait.and.arrow.right", role: .destructive) {
                    confirmLogout = true
                }.disabled(model.work.busy)
            }
        }
        .navigationTitle(L10n.text("settings"))
        .confirmationDialog(L10n.text("confirmLogout"), isPresented: $confirmLogout, titleVisibility: .visible) {
            Button(L10n.text("signOut"), role: .destructive) { Task { await model.logout() } }
        }
    }
}
