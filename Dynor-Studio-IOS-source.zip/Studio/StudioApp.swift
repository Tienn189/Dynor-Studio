import LocalAuthentication
import Observation
import SwiftUI

enum L10n {
    static let languageKey = "studio.language"
    static func text(_ key: String) -> String {
        let wanted = UserDefaults.standard.string(forKey: languageKey) ?? "system"
        let language = wanted == "system" ? Bundle.main.preferredLocalizations.first ?? "en" : wanted
        if let path = Bundle.main.path(forResource: language, ofType: "lproj"),
           let bundle = Bundle(path: path) {
            return bundle.localizedString(forKey: key, value: nil, table: nil)
        }
        return Bundle.main.localizedString(forKey: key, value: nil, table: nil)
    }

    static func date(_ raw: String?) -> String {
        guard let raw, !raw.isEmpty else { return "—" }
        let iso = ISO8601DateFormatter()
        iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        var date = iso.date(from: raw)
        if date == nil {
            iso.formatOptions = [.withInternetDateTime]
            date = iso.date(from: raw)
        }
        let language = UserDefaults.standard.string(forKey: languageKey) ?? "system"
        let locale = language == "system" ? Locale.current : Locale(identifier: language)
        return date?.formatted(Date.FormatStyle(date: .abbreviated, time: .shortened, locale: locale)) ?? raw
    }
}

@MainActor
@Observable
final class Work {
    var busy = false
    var error: String?
    var notice: String?
    var progress: Double?

    func run(_ operation: () async throws -> Void) async {
        guard !busy else { return }
        busy = true
        error = nil
        notice = nil
        progress = nil
        defer { busy = false; progress = nil }
        do { try await operation() }
        catch is CancellationError {}
        catch { self.error = error.localizedDescription }
    }
}

enum StudioTab: Hashable { case overview, wallpapers, vault, users, settings }
enum UserFocus: String { case vip, gift }

@MainActor
@Observable
final class StudioModel {
    let auth: AuthService
    let access: AccessService
    let control: ControlService
    let wallpapers: WallpaperService
    let vault: VaultService
    private(set) var vaultState = VaultState()
    let work = Work()
    var admin: AdminUser?
    var tab: StudioTab = .overview
    var startup = true
    var locked = false
    var online: Bool?
    var draft: WallpaperDraft?
    var wallpaperRevision = 0
    private(set) var accessRevision = 0
    private(set) var accounts: [Account]?
    let accountsWork = Work()
    private var accountsRequest: Task<[Account], Error>?
    private var accountsGeneration = UUID()
    var controlRevision = 0
    var userFocus: UserFocus?
    var initialCheckDone = false
    var privacyCover = false
    private var signingOut = false

    init() {
        let auth = AuthService()
        self.auth = auth
        access = AccessService(auth: auth)
        control = ControlService(auth: auth)
        wallpapers = WallpaperService(auth: auth)
        vault = VaultService(auth: auth)
    }

    func restore() async {
        guard !initialCheckDone, !signingOut else { return }
        await work.run {
            defer { startup = false }
            admin = try await auth.restore()
            online = admin == nil ? nil : true
            locked = admin != nil && faceIDEnabled
            initialCheckDone = true
        }
    }

    func recheck() async {
        guard let expected = admin?.id, !signingOut else { return }
        do {
            _ = try await auth.authorized()
            if admin?.id == expected { online = true }
        } catch let error as StudioError {
            guard admin?.id == expected else { return }
            switch error {
            case .denied, .expired:
                clearUI()
                work.error = error.localizedDescription
            default: online = false
            }
        } catch {
            if admin?.id == expected { online = false }
        }
    }

    func login(_ operation: () async throws -> AdminUser) async {
        await work.run {
            let user = try await operation()
            admin = user
            initialCheckDone = true
            online = true
            locked = faceIDEnabled
        }
    }

    func loadAccounts(force: Bool = false) async throws -> [Account] {
        guard admin != nil, !signingOut else { throw StudioError.expired }
        if let accountsRequest { return try await accountsRequest.value }
        if !force, let accounts { return accounts }

        let generation = accountsGeneration
        accountsWork.busy = true
        accountsWork.error = nil
        let request = Task { @MainActor () throws -> [Account] in
            defer {
                if generation == accountsGeneration {
                    accountsRequest = nil
                    accountsWork.busy = false
                }
            }
            do {
                let fresh = try await access.allAccounts()
                try Task.checkCancellation()
                guard generation == accountsGeneration else { throw CancellationError() }
                accounts = fresh
                return fresh
            } catch {
                if generation == accountsGeneration, !(error is CancellationError) {
                    accountsWork.error = error.localizedDescription
                }
                throw error
            }
        }
        accountsRequest = request
        return try await request.value
    }

    func refreshAccounts(force: Bool = true) async {
        _ = try? await loadAccounts(force: force)
    }

    func accountAccessChanged() {
        cancelAccountsRequest()
        accessRevision += 1
    }

    private func cancelAccountsRequest() {
        accountsGeneration = UUID()
        accountsRequest?.cancel()
        accountsRequest = nil
        accountsWork.busy = false
        accountsWork.error = nil
    }

    private func clearUI() {
        cancelAccountsRequest()
        accounts = nil
        vaultState = VaultState()
        draft = nil
        userFocus = nil
        admin = nil
        online = nil
        locked = false
        tab = .overview
    }

    func logout() async {
        guard !signingOut else { return }
        signingOut = true
        defer { signingOut = false }
        await work.run {
            defer { clearUI() }
            try await auth.signOut()
        }
    }

    var faceIDEnabled: Bool {
        UserDefaults.standard.bool(forKey: "studio.faceid")
    }

    func authenticateFace() async throws {
        let context = LAContext()
        guard context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: nil),
              context.biometryType == .faceID else { throw StudioError.message("faceUnavailable") }
        if try await context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: L10n.text("faceReason")) {
            locked = false
        }
    }

    func publish(_ file: StudioFile? = nil, tier: Tier = .free) {
        tab = .wallpapers
        draft = WallpaperDraft(package: file, tier: tier)
    }

    func users(_ focus: UserFocus) {
        userFocus = focus
        tab = .users
    }
}

@main
struct StudioApp: App {
    @State private var model = StudioModel()
    @AppStorage(L10n.languageKey) private var language = "system"
    @AppStorage("studio.appearance") private var appearance = "system"
    @AppStorage("studio.accent") private var accent = "D6A93F"
    @Environment(\.scenePhase) private var phase

    var body: some Scene {
        WindowGroup {
            root
                .environment(model)
                .environment(\.locale, language == "system" ? .current : Locale(identifier: language))
                .preferredColorScheme(appearance == "light" ? .light : appearance == "dark" ? .dark : nil)
                .tint(Color(studioHex: accent))
                .task { await model.restore() }
                .task(id: model.admin?.id) {
                    guard model.admin != nil else { return }
                    while !Task.isCancelled {
                        do { try await Task.sleep(for: .seconds(25)) } catch { return }
                        if phase == .active { await model.recheck() }
                    }
                }
                .onChange(of: phase) { _, newPhase in
                    model.privacyCover = newPhase != .active
                    if newPhase == .background, model.faceIDEnabled, model.admin != nil { model.locked = true }
                    if newPhase == .active { Task { await model.recheck() } }
                }
        }
    }

    @ViewBuilder private var root: some View {
        ZStack {
            if model.startup {
                ProgressView("Dynor Studio")
            } else if model.admin != nil {
                if model.locked { LockScreen() }
                else { StudioTabs() }
            } else {
                LoginScreen()
            }
            if model.privacyCover && model.admin != nil {
                Rectangle().fill(.background).ignoresSafeArea()
                Image(systemName: "lock.shield").font(.largeTitle).foregroundStyle(.secondary)
            }
        }
    }
}

struct StudioTabs: View {
    @Environment(StudioModel.self) private var model

    var body: some View {
        @Bindable var model = model
        TabView(selection: $model.tab) {
            Tab(L10n.text("overview"), systemImage: "square.grid.2x2", value: .overview) {
                NavigationStack { OverviewScreen() }
            }
            Tab(L10n.text("wallpapers"), systemImage: "photo.on.rectangle", value: .wallpapers) {
                NavigationStack { WallListScreen() }
            }
            Tab("Vault", systemImage: "lock.shield", value: .vault) {
                NavigationStack { VaultScreen() }
            }
            Tab(L10n.text("users"), systemImage: "person.2", value: .users) {
                NavigationStack { UserListScreen() }
            }
            Tab(L10n.text("settings"), systemImage: "gearshape", value: .settings) {
                NavigationStack { SettingsScreen() }
            }
        }
        .sheet(item: $model.draft) { draft in
            NavigationStack { WallEditor(draft: draft) }
                .presentationDragIndicator(.visible)
        }
    }
}
