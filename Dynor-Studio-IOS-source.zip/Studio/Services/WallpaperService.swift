import Foundation
import UniformTypeIdentifiers

struct Wallpaper: Identifiable, Sendable {
    let id: String
    let record: JSONObject

    init(_ record: JSONObject) throws {
        guard let id = record["id"]?.string, UUID(uuidString: id) != nil,
              record["title"]?.string != nil else { throw StudioError.message("invalidResponse") }
        self.id = id
        self.record = record
    }

    var title: String { record["title"]?.string ?? "" }
    var description: String { record["description"]?.string ?? "" }
    var category: String { record["category"]?.string ?? "" }
    var cover: String? { record["image_url"]?.string }
    var video: String? { record["preview_video_url"]?.string }
    var oldDownload: String? { record["tendies_url"]?.string }
    var file: String? { record["file_path"]?.string }
    var filename: String? { record["file_name"]?.string }
    var tier: Tier? {
        if let raw = record["access_tier"]?.string { return Tier(rawValue: raw) }
        return record["is_vip"]?.bool == true ? .crown : .free
    }
    var published: Bool { record["published"]?.bool ?? record["is_published"]?.bool ?? false }
}

struct WallpaperDraft: Identifiable, Sendable {
    let id = UUID()
    let existing: Wallpaper?
    var title: String
    var description: String
    var category: String
    var tier: Tier?
    var published: Bool
    var cover: StudioFile?
    var video: StudioFile?
    var package: StudioFile?

    init(existing: Wallpaper? = nil, package: StudioFile? = nil, tier: Tier = .free) {
        self.existing = existing
        self.package = package
        title = existing?.title ?? ""
        description = existing?.description ?? ""
        category = existing?.category ?? "Phong cảnh"
        self.tier = existing == nil ? tier : existing?.tier
        published = existing?.published ?? true
    }
}

struct WallpaperService: Sendable {
    static func importPackage(_ url: URL) async throws -> StudioFile {
        let file = try await StudioFile.imported(url, limit: PackageInfo.sealedLimit, requiredExtension: .dynor)
        try await Task.detached(priority: .userInitiated) {
            let handle = try FileHandle(forReadingFrom: file.url)
            defer { try? handle.close() }
            let prefix = try handle.read(upToCount: PackageInfo.magic.count) ?? Data()
            try PackageInfo.validateEnvelope(prefix: prefix, size: file.size)
        }.value
        return file
    }

    static let previews = "dynor-wallpapers"
    static let downloads = "dynor-downloads"
    private let table = "rest/v1/dynor_wallpapers"
    let auth: AuthService
    private let api = APIClient()

    private struct Object: Sendable, Hashable {
        let bucket: String
        let path: String
        var publicURL: String? {
            guard bucket == WallpaperService.previews else { return nil }
            return APIClient.url("storage/v1/object/public/\(bucket)/\(path)").absoluteString
        }
    }

    func list() async throws -> [Wallpaper] {
        let token = try await auth.authorized().token
        var rows: [Wallpaper] = []
        var ids = Set<String>()
        while true {
            try Task.checkCancellation()
            let (data, _) = try await api.call(table, token: token, query: [
                .init(name: "select", value: "*"), .init(name: "order", value: "created_at.desc,id.desc"),
                .init(name: "offset", value: String(rows.count)), .init(name: "limit", value: "200")
            ])
            let batch = try api.decode([JSONObject].self, data).map(Wallpaper.init)
            if batch.isEmpty { return rows }
            guard batch.allSatisfy({ ids.insert($0.id).inserted }) else {
                throw StudioError.message("wallpapersChanged")
            }
            rows += batch
        }
    }

    func find(_ id: String) async throws -> Wallpaper? {
        let token = try await auth.authorized().token
        let (data, _) = try await api.call(table, token: token, query: [
            .init(name: "select", value: "*"), .init(name: "id", value: "eq." + id)
        ])
        return try api.decode([JSONObject].self, data).first.map(Wallpaper.init)
    }

    func previewURL(_ raw: String) async -> URL? {
        guard let url = URL(string: raw), url.scheme?.lowercased() == "https" else { return nil }
        guard let object = previewObject(raw) else { return url }
        do {
            let token = try await auth.authorized().token
            let (data, _) = try await api.call("storage/v1/object/sign/\(object.bucket)/\(object.path)",
                method: "POST", token: token, body: ["expiresIn": .number(900)], privateBody: true)
            guard let signed = try api.decode(JSONObject.self, data)["signedURL"]?.string,
                  signed.hasPrefix("/object/sign/") else { return url }
            return URL(string: "/storage/v1" + signed, relativeTo: APIClient.base)?.absoluteURL
        } catch { return url }
    }

    private func previewObject(_ raw: String?) -> Object? {
        guard let raw, let url = URL(string: raw), url.scheme == "https", url.host == APIClient.base.host,
              url.port == nil else { return nil }
        let prefix = "/storage/v1/object/public/\(Self.previews)/"
        let path = String(url.path.dropFirst(prefix.count))
        guard url.path.hasPrefix(prefix), validPath(path) else { return nil }
        return Object(bucket: Self.previews, path: path)
    }

    private func validPath(_ path: String) -> Bool {
        path.split(separator: "/", omittingEmptySubsequences: false).allSatisfy {
            !$0.isEmpty && $0 != "." && $0 != ".."
        }
    }

    private func downloadObject(_ path: String?) -> Object? {
        guard let path, validPath(path) else { return nil }
        return Object(bucket: Self.downloads, path: path)
    }

    private func storedPackage(_ path: String?, token: String) async throws -> PackageInfo {
        guard let object = downloadObject(path) else { throw StudioError.message("missingPackage") }
        let request = try api.request("storage/v1/object/authenticated/\(object.bucket)/\(object.path)", token: token,
                                      headers: ["Accept": "application/octet-stream"])
        let (file, response) = try await APIClient.session.download(for: request)
        defer { try? FileManager.default.removeItem(at: file) }
        _ = try api.checked(response, Data())
        return try await packageInfo(file)
    }

    private func packageInfo(_ file: URL) async throws -> PackageInfo {
        try await Task.detached(priority: .userInitiated) {
            let size = try file.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
            guard size > PackageInfo.overhead, size <= PackageInfo.sealedLimit else {
                throw StudioError.message("invalidPackage")
            }
            return try PackageInfo(Data(contentsOf: file, options: .mappedIfSafe))
        }.value
    }

    private func saveAtomic(_ id: String?, record: JSONObject, info: PackageInfo, token: String) async throws {
        _ = try await api.call("rest/v1/rpc/dynor_admin_save_wallpaper", method: "POST", token: token,
            body: ["p_id": .optional(id), "p_record": .object(record), "p_package_id": .string(info.id),
                   "p_sha256": .string(info.sha)])
    }

    private func upload(_ file: StudioFile, _ folder: String, _ object: Object,
                        token: String, progress: @escaping ProgressUpdate) async throws {
        let mime = folder == "tendies" ? "application/octet-stream"
            : UTType(filenameExtension: file.url.pathExtension)?.preferredMIMEType ?? "application/octet-stream"
        try await api.upload("storage/v1/object/\(object.bucket)/\(object.path)", token: token,
                             file: file.url, mime: mime, progress: progress)
    }

    private func clean(_ objects: Set<Object>, token: String) async -> Bool {
        var complete = true
        for bucket in [Self.previews, Self.downloads] {
            let paths = objects.filter { $0.bucket == bucket }.map { JSONValue.string($0.path) }
            guard !paths.isEmpty else { continue }
            do {
                _ = try await api.call("storage/v1/object/\(bucket)", method: "DELETE", token: token,
                                       body: ["prefixes": .array(paths)])
            } catch { complete = false }
        }
        return complete
    }

    func save(_ draft: WallpaperDraft, progress: @escaping ProgressUpdate) async throws -> Bool {
        guard !draft.title.trimmed.isEmpty, let tier = draft.tier else { throw StudioError.message("wallpaperFields") }
        guard draft.existing != nil || draft.cover != nil else { throw StudioError.message("missingCover") }
        let token = try await auth.authorized().token
        let info: PackageInfo
        if let package = draft.package { info = try await packageInfo(package.url) }
        else { info = try await storedPackage(draft.existing?.file, token: token) }

        var cover = draft.existing?.cover ?? ""
        var video = draft.existing?.video
        var legacy = draft.existing?.oldDownload
        var filePath = draft.existing?.file
        var filename = draft.existing?.filename
        var uploaded = Set<Object>()
        let files: [(StudioFile, String)] = [(draft.cover, "images"), (draft.video, "videos"), (draft.package, "tendies")]
            .compactMap { file, folder in file.map { ($0, folder) } }
        do {
            for (index, (file, folder)) in files.enumerated() {
                try Task.checkCancellation()
                let ext = file.url.pathExtension.lowercased().filter { $0.isASCII && ($0.isLetter || $0.isNumber) }
                let bucket = folder == "tendies" ? Self.downloads : Self.previews
                let object = Object(bucket: bucket, path: "\(folder)/\(UUID().uuidString.lowercased()).\(ext.nonEmpty ?? "bin")")
                uploaded.insert(object)
                try await upload(file, folder, object, token: token) { fraction in
                    await progress(0.1 + 0.8 * (Double(index) + fraction) / Double(files.count))
                }
                switch folder {
                case "images": cover = object.publicURL ?? ""
                case "videos": video = object.publicURL
                default: filePath = object.path; filename = file.name; legacy = nil
                }
            }
        } catch {
            if !(await clean(uploaded, token: token)) { throw StudioError.message("cleanupPending") }
            throw error
        }
        let record: JSONObject = [
            "title": .string(draft.title.trimmed), "description": .optional(draft.description.trimmed.nonEmpty),
            "category": .string(draft.category.trimmed.nonEmpty ?? "Tất cả"),
            "image_url": .string(cover), "cover_path": .string(cover),
            "preview_video_url": .optional(video), "video_path": .optional(video),
            "tendies_url": .optional(legacy), "file_path": .optional(filePath), "file_name": .optional(filename),
            "access_tier": .string(tier.rawValue), "is_vip": .bool(tier == .crown),
            "is_published": .bool(draft.published), "published": .bool(draft.published)
        ]
        do {
            try await saveAtomic(draft.existing?.id, record: record, info: info, token: token)
        } catch {
            // A connection failure after dispatch can hide a committed transaction.
            if let status = (error as? StudioError)?.status, (400..<500).contains(status), status != 408 {
                if !(await clean(uploaded, token: token)) { throw StudioError.message("cleanupPending") }
                throw error
            }
            throw StudioError.message("saveUncertain")
        }
        await progress(1)
        guard let old = draft.existing else { return true }
        let replaced = Set([
            draft.cover != nil ? previewObject(old.cover) : nil,
            draft.video != nil ? previewObject(old.video) : nil,
            draft.package != nil ? previewObject(old.oldDownload) : nil,
            draft.package != nil ? downloadObject(old.file) : nil
        ].compactMap { $0 })
        let retained = Set([previewObject(cover), previewObject(video), previewObject(legacy),
                            downloadObject(filePath)].compactMap { $0 })
        return await clean(replaced.subtracting(retained), token: token)
    }

    func sync(_ wallpaper: Wallpaper) async throws -> PackageInfo {
        let token = try await auth.authorized().token
        let info = try await storedPackage(wallpaper.file, token: token)
        var record = wallpaper.record
        record["published"] = .bool(wallpaper.published)
        record["is_published"] = .bool(wallpaper.published)
        try await saveAtomic(wallpaper.id, record: record, info: info, token: token)
        return info
    }

    func delete(_ wallpaper: Wallpaper) async throws -> Bool {
        let token = try await auth.authorized().token
        let (data, _) = try await api.call(table, method: "DELETE", token: token,
            query: [.init(name: "id", value: "eq." + wallpaper.id), .init(name: "select", value: "id")],
            headers: ["Prefer": "return=representation"])
        guard try api.decode([JSONObject].self, data).first?["id"]?.string == wallpaper.id else {
            throw StudioError.message("deleteNoMatch")
        }
        return await clean(Set([previewObject(wallpaper.cover), previewObject(wallpaper.video),
                                previewObject(wallpaper.oldDownload), downloadObject(wallpaper.file)].compactMap { $0 }),
                           token: token)
    }
}
