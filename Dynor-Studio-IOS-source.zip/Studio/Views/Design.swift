import SwiftUI
import UIKit

enum StudioDesign {
    static let canvas = Color(uiColor: .systemGroupedBackground)
    static let surface = Color(uiColor: .secondarySystemGroupedBackground)
    static let radius: CGFloat = 20
}

extension Color {
    init(studioHex raw: String) {
        let value = UInt32(raw, radix: 16) ?? 0xD6A93F
        self.init(red: Double((value >> 16) & 255) / 255, green: Double((value >> 8) & 255) / 255,
                  blue: Double(value & 255) / 255)
    }

    var studioHex: String? {
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        guard UIColor(self).getRed(&r, green: &g, blue: &b, alpha: &a) else { return nil }
        return String(format: "%02X%02X%02X", Int((r * 255).rounded()), Int((g * 255).rounded()), Int((b * 255).rounded()))
    }
}

struct StudioGlass: ViewModifier {
    @Environment(\.accessibilityReduceTransparency) private var reduceTransparency
    var interactive = false

    func body(content: Content) -> some View {
        content
            .background(reduceTransparency ? StudioDesign.surface : .clear, in: .rect(cornerRadius: 16))
            .glassEffect(reduceTransparency ? .identity : .regular.interactive(interactive),
                         in: .rect(cornerRadius: 16))
    }
}

struct StudioCard<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        content
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(StudioDesign.surface, in: RoundedRectangle(cornerRadius: StudioDesign.radius))
    }
}

struct StudioAction: View {
    let key: String
    let symbol: String
    var primary = false
    let action: () -> Void

    @ViewBuilder var body: some View {
        if primary {
            Button(action: action) {
                Label(L10n.text(key), systemImage: symbol).font(.body.weight(.semibold))
                    .frame(maxWidth: .infinity, minHeight: 26)
            }
            .buttonStyle(.glassProminent)
            .buttonBorderShape(.roundedRectangle(radius: 16))
            .controlSize(.large)
        } else {
            Button(action: action) {
                Label(L10n.text(key), systemImage: symbol).font(.body.weight(.medium))
                    .frame(maxWidth: .infinity, minHeight: 26, alignment: .leading)
                    .padding(12)
                    .modifier(StudioGlass(interactive: true))
            }
            .buttonStyle(.plain)
        }
    }
}

struct WorkStatus: View {
    var work: Work
    var retry: (() -> Void)? = nil

    var body: some View {
        if work.busy {
            if let progress = work.progress { ProgressView(value: progress) }
            else { ProgressView(L10n.text("working")) }
        }
        if let error = work.error {
            Label(error, systemImage: "exclamationmark.circle")
                .font(.callout)
                .foregroundStyle(.red)
                .textSelection(.enabled)
            if let retry { Button(L10n.text("retry"), action: retry) }
        }
        if let notice = work.notice {
            Label(notice, systemImage: "checkmark.circle")
                .font(.callout).foregroundStyle(.secondary).textSelection(.enabled)
        }
    }
}

struct StudioEmpty: View {
    let key: String
    let symbol: String

    var body: some View { ContentUnavailableView(L10n.text(key), systemImage: symbol) }
}

struct TierMark: View {
    let tier: Tier?

    var body: some View {
        if let tier, let symbol = tier.symbol {
            Label(L10n.text(tier.rawValue), systemImage: symbol)
                .labelStyle(.iconOnly)
                .accessibilityLabel(L10n.text(tier.rawValue))
                .foregroundStyle(tier == .crown ? Color.accentColor : Color.secondary)
        }
    }
}

struct AuditRow: View {
    let entry: AuditEntry

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(L10n.text("audit." + entry.action) == "audit." + entry.action
                 ? entry.action : L10n.text("audit." + entry.action)).font(.subheadline.weight(.semibold))
            Text(L10n.date(entry.created_at)).font(.caption).foregroundStyle(.secondary)
            if let actor = entry.actor {
                LabeledContent(L10n.text("actor"), value: actor).font(.caption)
            }
            if let target = entry.target {
                LabeledContent(L10n.text("target"), value: target).font(.caption)
            }
        }.textSelection(.enabled)
    }
}

struct RemoteCover: View {
    @Environment(StudioModel.self) private var model
    let raw: String?
    @State private var url: URL?

    var body: some View {
        AsyncImage(url: url) { phase in
            if let image = phase.image { image.resizable().scaledToFill() }
            else if url != nil && phase.error == nil { ProgressView() }
            else { Image(systemName: "photo").foregroundStyle(.tertiary) }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(uiColor: .tertiarySystemFill))
        .clipped()
        .accessibilityHidden(true)
        .task(id: raw) {
            url = nil
            if let raw { url = await model.wallpapers.previewURL(raw) }
        }
    }
}
