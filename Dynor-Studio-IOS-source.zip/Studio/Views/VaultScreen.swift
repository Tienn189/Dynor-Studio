import CoreTransferable
import SwiftUI
import UniformTypeIdentifiers

private struct VaultExport: Transferable {
    let file: StudioFile
    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(exportedContentType: .dynor) { item in SentTransferredFile(item.file.url) }
    }
}

struct VaultScreen: View {
    @Environment(StudioModel.self) private var model
    @State private var work = Work()
    @State private var source: StudioFile?
    @State private var encrypted: StudioFile?
    @State private var tier: Tier = .free
    @State private var imports = false
    @State private var export = false

    var body: some View {
        List {
            Section {
                Label(L10n.text("vaultNote"), systemImage: "shield.lefthalf.filled")
                    .font(.subheadline).foregroundStyle(.secondary)
                Button { imports = true } label: { Label(L10n.text("importTendies"), systemImage: "folder") }
                if let source {
                    LabeledContent {
                        Text(source.name).lineLimit(2)
                    } label: { Text(L10n.text("sourceFile")) }
                    Button(L10n.text("removeFile"), role: .destructive) {
                        self.source = nil
                        encrypted = nil
                    }
                }
                Picker(L10n.text("tier"), selection: $tier) {
                    ForEach(Tier.allCases) { tier in Text(L10n.text(tier.rawValue)).tag(tier) }
                }
                Text(L10n.text(tier.rawValue + "Hint")).font(.footnote).foregroundStyle(.secondary)
            }
            Section {
                StudioAction(key: "encrypt", symbol: "lock.fill", primary: true) { Task { await encrypt() } }
                    .disabled(source == nil)
            }.listRowBackground(Color.clear)
            if let encrypted {
                Section(L10n.text("encryptedFile")) {
                    Text(encrypted.name)
                    ShareLink(item: encrypted.url) {
                        Label(L10n.text("share"), systemImage: "square.and.arrow.up")
                    }
                    Button { export = true } label: { Label(L10n.text("exportFile"), systemImage: "folder") }
                    Button { model.publish(encrypted, tier: tier) } label: {
                        Label(L10n.text("publish"), systemImage: "arrow.up.circle")
                    }
                }
            }
            if work.busy || work.error != nil || work.notice != nil {
                Section { WorkStatus(work: work) }
            }
        }
        .disabled(work.busy)
        .navigationTitle("Vault")
        .onChange(of: tier) { _, _ in encrypted = nil }
        .fileImporter(isPresented: $imports, allowedContentTypes: [.tendies]) { result in
            Task {
                await work.run {
                    let candidate = try result.get()
                    guard candidate.pathExtension.lowercased() == "tendies" else {
                        throw StudioError.message("invalidTendies")
                    }
                    source = try await StudioFile.imported(candidate, limit: PackageInfo.plainLimit)
                    encrypted = nil
                }
            }
        }
        .fileExporter(isPresented: $export, item: encrypted.map { VaultExport(file: $0) }, contentTypes: [.dynor],
                      defaultFilename: encrypted?.url.deletingPathExtension().lastPathComponent) { result in
            Task {
                await work.run {
                    _ = try result.get()
                    work.notice = L10n.text("exported")
                }
            }
        }
    }

    private func encrypt() async {
        guard let source else { return }
        await work.run {
            encrypted = nil
            encrypted = try await model.vault.encrypt(source, tier: tier) { fraction in
                await MainActor.run { if work.busy { work.progress = fraction } }
            }
            work.notice = L10n.text("registered")
        }
    }
}
