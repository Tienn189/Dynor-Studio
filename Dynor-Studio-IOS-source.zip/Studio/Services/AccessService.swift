import Foundation

struct Account: Decodable, Identifiable, Sendable {
    struct VIP: Decodable, Sendable {
        let plan_id: String?
        let vip_expires_at: String?
    }

    struct Quota: Decodable, Sendable {
        let active: Bool?
        let unlimited: Bool?
        let remaining: Int?
    }

    let id: String
    let email: String?
    let created_at: String?
    let last_sign_in_at: String?
    let vip: VIP?
    let quota: Quota?
}

struct AccountPage: Decodable, Sendable {
    let accounts: [Account]
    let total: Int?
}

struct Gift: Decodable, Identifiable, Sendable {
    struct WallpaperTitle: Decodable, Sendable { let title: String? }
    let wallpaper_id: String
    let expires_at: String?
    let dynor_wallpapers: WallpaperTitle?
    var id: String { wallpaper_id }
    var title: String { dynor_wallpapers?.title ?? wallpaper_id }
}

struct AuditEntry: Decodable, Sendable {
    let created_at: String?
    let action: String
    let actor: String?
    let target: String?
}

struct GrantWallpaper: Decodable, Identifiable, Sendable {
    let id: String
    let title: String
    let image_url: String?
    let access_tier: String?
}

enum VIPPlan: String, CaseIterable, Identifiable {
    case week, month, quarter, lifetime
    var id: String { rawValue }
    var days: Int {
        switch self {
        case .week: return 7
        case .month: return 30
        case .quarter: return 90
        case .lifetime: return 0
        }
    }
}

enum AccountChange: Sendable {
    case vip(plan: String, days: Int)
    case revokeVIP
    case credits(Int)
    case gift(wallpaper: String, days: Int)
    case revokeGift(String)

    var payload: (String, JSONObject) {
        switch self {
        case .vip(let plan, let days): return ("vip", ["plan": .string(plan), "days": .number(Double(days))])
        case .revokeVIP: return ("revoke_vip", [:])
        case .credits(let delta): return ("credits", ["delta": .number(Double(delta))])
        case .gift(let id, let days): return ("gift", ["wallpaper_id": .string(id), "days": .number(Double(days))])
        case .revokeGift(let id): return ("revoke_gift", ["wallpaper_id": .string(id)])
        }
    }
}

struct AccessService: Sendable {
    let auth: AuthService
    private let api = APIClient()
    static let pageSize = 50

    private func invoke(_ action: String, fields: JSONObject = [:]) async throws -> Data {
        let token = try await auth.authorized().token
        var body = fields
        body["action"] = .string(action)
        let (data, _) = try await api.call("functions/v1/dynor-access", method: "POST", token: token, body: body)
        return data
    }

    func list(page: Int) async throws -> AccountPage {
        try await api.decode(AccountPage.self, invoke("list", fields: ["page": .number(Double(page))]))
    }

    func allAccounts() async throws -> [Account] {
        var page = 1
        var rows: [Account] = []
        var ids = Set<String>()
        while true {
            try Task.checkCancellation()
            let result = try await list(page: page)
            guard result.accounts.allSatisfy({ ids.insert($0.id).inserted }) else {
                throw StudioError.message("accountsChanged")
            }
            rows += result.accounts
            if let total = result.total {
                if rows.count == total { return rows }
                guard rows.count < total, result.accounts.count == Self.pageSize else {
                    throw StudioError.message("accountsChanged")
                }
            } else if result.accounts.count < Self.pageSize { return rows }
            page += 1
        }
    }

    func wallpapers() async throws -> [GrantWallpaper] {
        try await api.decode([GrantWallpaper].self, invoke("wallpapers"))
    }

    func gifts(_ target: String) async throws -> [Gift] {
        try await api.decode([Gift].self, invoke("gifts", fields: ["target": .string(target)]))
    }

    func audit() async throws -> [AuditEntry] {
        try await api.decode([AuditEntry].self, invoke("audit"))
    }

    func change(_ change: AccountChange, target: String) async throws {
        let (action, data) = change.payload
        _ = try await invoke(action, fields: ["target": .string(target), "data": .object(data)])
    }
}
