import CryptoKit
import Foundation
import UniformTypeIdentifiers

extension UTType {
    static let tendies = UTType(importedAs: "com.dynor.tendies")
    static let dynor = UTType(importedAs: "com.dynor.encrypted-wallpaper")
}

enum Tier: String, CaseIterable, Identifiable, Sendable {
    case free, premium, crown
    var id: String { rawValue }
    var symbol: String? {
        switch self {
        case .free: return nil
        case .premium: return "diamond.fill"
        case .crown: return "crown.fill"
        }
    }
}

final class StudioFile: Sendable {
    let url: URL
    let size: Int
    var name: String { url.lastPathComponent }
    private let directory: URL

    private init(url: URL, size: Int, directory: URL) {
        self.url = url
        self.size = size
        self.directory = directory
    }

    deinit { try? FileManager.default.removeItem(at: directory) }

    private static func workspace() throws -> URL {
        let directory = FileManager.default.temporaryDirectory
            .appendingPathComponent("Studio-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: false,
                                                attributes: [.protectionKey: FileProtectionType.complete])
        return directory
    }

    static func imported(_ source: URL, limit: Int) async throws -> StudioFile {
        try await Task.detached(priority: .userInitiated) {
            let scoped = source.startAccessingSecurityScopedResource()
            defer { if scoped { source.stopAccessingSecurityScopedResource() } }
            let directory = try workspace()
            do {
                let url = directory.appendingPathComponent(source.lastPathComponent)
                var readError: NSError?
                var result: Result<Int, Error>?
                NSFileCoordinator().coordinate(readingItemAt: source, options: [], error: &readError) { readable in
                    result = Result {
                        let values = try readable.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
                        guard values.isRegularFile == true, let size = values.fileSize, size > 0, size <= limit else {
                            throw StudioError.message("fileSize")
                        }
                        try FileManager.default.copyItem(at: readable, to: url)
                        try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete],
                                                              ofItemAtPath: url.path)
                        let copiedSize = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize
                        guard let copiedSize, copiedSize > 0, copiedSize <= limit else {
                            throw StudioError.message("fileSize")
                        }
                        return copiedSize
                    }
                }
                if let readError { throw readError }
                guard let result else { throw StudioError.message("fileUnreadable") }
                return StudioFile(url: url, size: try result.get(), directory: directory)
            } catch {
                try? FileManager.default.removeItem(at: directory)
                throw error
            }
        }.value
    }

    static func generated(_ bytes: Data, name: String) throws -> StudioFile {
        let directory = try workspace()
        do {
            let url = directory.appendingPathComponent(name)
            try bytes.write(to: url, options: [.atomic, .completeFileProtection])
            return StudioFile(url: url, size: bytes.count, directory: directory)
        } catch {
            try? FileManager.default.removeItem(at: directory)
            throw error
        }
    }
}

struct PackageInfo: Sendable {
    static let magic = Data("DYNORT01".utf8)
    static let plainLimit = 50 * 1024 * 1024
    static let overhead = 52
    static let sealedLimit = plainLimit + overhead

    let id: String
    let sha: String

    init(_ bytes: Data) throws {
        guard bytes.count > Self.overhead, bytes.count <= Self.sealedLimit, bytes.starts(with: Self.magic) else {
            throw StudioError.message("invalidPackage")
        }
        let uuid = Array(bytes.dropFirst(8).prefix(16))
        id = UUID(uuid: (uuid[0], uuid[1], uuid[2], uuid[3], uuid[4], uuid[5], uuid[6], uuid[7],
                         uuid[8], uuid[9], uuid[10], uuid[11], uuid[12], uuid[13], uuid[14], uuid[15]))
            .uuidString.lowercased()
        sha = SHA256.hash(data: bytes).map { String(format: "%02x", $0) }.joined()
    }
}

struct VaultService: Sendable {
    let auth: AuthService
    private let api = APIClient()

    static func seal(_ plaintext: Data, id: UUID, key: SymmetricKey,
                     nonce: AES.GCM.Nonce) throws -> Data {
        guard (4...PackageInfo.plainLimit).contains(plaintext.count),
              plaintext.starts(with: [0x50, 0x4b, 0x03, 0x04])
                  || plaintext.starts(with: [0x50, 0x4b, 0x05, 0x06]),
              key.bitCount == 256 else {
            throw StudioError.message("invalidTendies")
        }
        var uuid = id.uuid
        var header = PackageInfo.magic
        withUnsafeBytes(of: &uuid) { header.append(contentsOf: $0) }
        let box = try AES.GCM.seal(plaintext, using: key, nonce: nonce, authenticating: header)
        guard let combined = box.combined else { throw StudioError.message("invalidPackage") }
        header.append(combined)
        return header
    }

    func encrypt(_ source: StudioFile, tier: Tier, progress: @escaping ProgressUpdate) async throws -> StudioFile {
        guard source.url.pathExtension.lowercased() == "tendies",
              (9...255).contains(source.name.unicodeScalars.count), source.name == source.name.trimmed,
              !source.name.unicodeScalars.contains(where: { $0.value < 32 || $0.value == 127 || $0 == "/" || $0 == "\\" }),
              source.size <= PackageInfo.plainLimit else {
            throw StudioError.message("invalidTendies")
        }
        _ = try await auth.authorized()
        let key = SymmetricKey(size: .bits256)
        let encrypted = try await Task.detached(priority: .userInitiated) {
            await progress(0.15)
            var plaintext = try Data(contentsOf: source.url)
            defer { plaintext.resetBytes(in: 0..<plaintext.count) }
            await progress(0.35)
            let bytes = try Self.seal(plaintext, id: UUID(), key: key, nonce: AES.GCM.Nonce())
            return (bytes, try PackageInfo(bytes))
        }.value
        try Task.checkCancellation()
        let info = encrypted.1
        await progress(0.7)
        let token = try await auth.authorized().token
        var keyBytes = key.withUnsafeBytes { Data($0) }
        defer { keyBytes.resetBytes(in: 0..<keyBytes.count) }
        let (data, _) = try await api.call("functions/v1/dynor-register-package", method: "POST", token: token,
             body: ["package_id": .string(info.id), "sha256": .string(info.sha),
                    "key_base64": .string(keyBytes.base64EncodedString()), "original_name": .string(source.name),
                    "requires_vip": .bool(tier != .free), "access_tier": .string(tier.rawValue)], privateBody: true)
        let receipt = try api.decode(JSONObject.self, data)
        guard receipt["package_id"]?.string == info.id, receipt["sha256"]?.string == info.sha else {
            throw StudioError.message("registrationMismatch")
        }
        let output = try await Task.detached {
            let basename = source.url.deletingPathExtension().lastPathComponent
            return try StudioFile.generated(encrypted.0, name: (basename.nonEmpty ?? "wallpaper") + ".dynor")
        }.value
        await progress(1)
        return output
    }
}
