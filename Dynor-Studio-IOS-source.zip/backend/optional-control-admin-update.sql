-- Apply only if the deployed row-1 configuration lacks an approved Admin update policy.
-- Depends on the existing public.dynor_is_admin() from wallpaper_online.sql.
begin;
grant update (
  maintenance_enabled, force_update, minimum_build, latest_version,
  update_title, update_message, telegram_url, maintenance_title,
  maintenance_message, maintenance_eta, updated_at
) on public.dynor_app_control to authenticated;

drop policy if exists "Dynor Studio Admin updates row 1" on public.dynor_app_control;
create policy "Dynor Studio Admin updates row 1"
  on public.dynor_app_control
  for update to authenticated
  using (id = 1 and (select public.dynor_is_admin()))
  with check (id = 1 and (select public.dynor_is_admin()));
commit;
